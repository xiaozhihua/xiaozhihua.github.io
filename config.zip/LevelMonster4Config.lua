-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-10 15:32:02
LevelMonster4Config = {}
LevelMonster4Config[4601] =
	{   
		pass_id = 46, 
		type_count_start1 = {404,10,100,0,407,10,100,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4602] =
	{   
		pass_id = 46, 
		type_count_start1 = {404,10,240,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4603] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,10,360,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4604] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,5,550,0,404,5,550,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4605] =
	{   
		pass_id = 46, 
		type_count_start1 = {413,10,850,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4606] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,6,875,0,401,4,687,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4607] =
	{   
		pass_id = 46, 
		type_count_start1 = {416,10,700,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4608] =
	{   
		pass_id = 46, 
		type_count_start1 = {419,6,1280,0,401,4,704,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4609] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,10,1200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4610] =
	{   
		pass_id = 46, 
		type_count_start1 = {405,1,3500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4611] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,6,1650,0,404,4,1650,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4612] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,6,1696,0,416,4,1332,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4613] =
	{   
		pass_id = 46, 
		type_count_start1 = {416,5,1500,0,401,5,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4614] =
	{   
		pass_id = 46, 
		type_count_start1 = {419,7,1907,0,401,3,1049,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4615] =
	{   
		pass_id = 46, 
		type_count_start1 = {413,7,1796,0,410,3,1976,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4616] =
	{   
		pass_id = 46, 
		type_count_start1 = {413,6,2316,0,416,4,1274,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4617] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,5,2120,0,404,5,2120,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4618] =
	{   
		pass_id = 46, 
		type_count_start1 = {407,5,2274,0,401,5,1786,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4619] =
	{   
		pass_id = 46, 
		type_count_start1 = {401,10,1850,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4620] =
	{   
		pass_id = 46, 
		type_count_start1 = {419,5,1250,0,413,1,1250,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4701] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,10,60,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4702] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,10,135,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4703] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,10,260,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4704] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,6,400,0,404,4,400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4705] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,5,476,0,404,5,476,0,416,5,374,0,401,5,374,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4706] =
	{   
		pass_id = 47, 
		type_count_start1 = {413,10,900,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4707] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,6,1067,0,413,4,1524,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4708] =
	{   
		pass_id = 47, 
		type_count_start1 = {419,6,1585,0,401,4,872,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4709] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,7,1496,0,416,3,1175,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4710] =
	{   
		pass_id = 47, 
		type_count_start1 = {408,1,2750,0,405,1,2750,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4711] =
	{   
		pass_id = 47, 
		type_count_start1 = {419,7,1553,0,410,3,1708,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4712] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,10,1800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4713] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,6,2100,0,404,4,2100,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4714] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,5,2261,0,401,5,1739,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4715] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,10,2161,0,411,1,3395,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4716] =
	{   
		pass_id = 47, 
		type_count_start1 = {413,10,2600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4717] =
	{   
		pass_id = 47, 
		type_count_start1 = {419,10,2900,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4718] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,6,3063,0,416,4,2406,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4719] =
	{   
		pass_id = 47, 
		type_count_start1 = {416,10,2650,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4720] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,5,3217,0,401,15,2527,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4721] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,10,3000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4722] =
	{   
		pass_id = 47, 
		type_count_start1 = {407,5,3400,0,404,5,3400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4723] =
	{   
		pass_id = 47, 
		type_count_start1 = {404,6,3937,0,416,4,3093,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4724] =
	{   
		pass_id = 47, 
		type_count_start1 = {410,3,4272,3000,413,7,3883,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4725] =
	{   
		pass_id = 47, 
		type_count_start1 = {403,5,12000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4801] =
	{   
		pass_id = 48, 
		type_count_start1 = {419,10,60,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4802] =
	{   
		pass_id = 48, 
		type_count_start1 = {413,6,136,0,404,4,95,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4803] =
	{   
		pass_id = 48, 
		type_count_start1 = {404,10,240,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4804] =
	{   
		pass_id = 48, 
		type_count_start1 = {407,6,441,0,416,4,339,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4805] =
	{   
		pass_id = 48, 
		type_count_start1 = {401,10,350,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4806] =
	{   
		pass_id = 48, 
		type_count_start1 = {404,10,550,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4807] =
	{   
		pass_id = 48, 
		type_count_start1 = {407,10,650,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4808] =
	{   
		pass_id = 48, 
		type_count_start1 = {419,8,882,0,410,2,970,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4809] =
	{   
		pass_id = 48, 
		type_count_start1 = {407,5,900,0,404,5,900,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4810] =
	{   
		pass_id = 48, 
		type_count_start1 = {414,1,3250,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4811] =
	{   
		pass_id = 48, 
		type_count_start1 = {419,5,1483,0,416,5,816,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4812] =
	{   
		pass_id = 48, 
		type_count_start1 = {401,10,900,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4813] =
	{   
		pass_id = 48, 
		type_count_start1 = {404,10,1280,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4814] =
	{   
		pass_id = 48, 
		type_count_start1 = {404,5,1450,0,407,5,1450,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4815] =
	{   
		pass_id = 48, 
		type_count_start1 = {407,10,1566,0,413,5,2236,0,416,5,1230,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4816] =
	{   
		pass_id = 48, 
		type_count_start1 = {419,10,1700,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4817] =
	{   
		pass_id = 48, 
		type_count_start1 = {404,8,1671,0,401,2,1313,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4818] =
	{   
		pass_id = 48, 
		type_count_start1 = {401,5,1500,0,416,5,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4819] =
	{   
		pass_id = 48, 
		type_count_start1 = {407,10,1880,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4820] =
	{   
		pass_id = 48, 
		type_count_start1 = {418,1,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4901] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,10,60,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4902] =
	{   
		pass_id = 49, 
		type_count_start1 = {413,10,120,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4903] =
	{   
		pass_id = 49, 
		type_count_start1 = {404,5,988,0,419,5,1411,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4904] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,5,2000,0,404,5,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4905] =
	{   
		pass_id = 49, 
		type_count_start1 = {416,10,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4906] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,6,2406,0,401,4,1890,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4907] =
	{   
		pass_id = 49, 
		type_count_start1 = {404,5,2553,0,413,5,3646,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4908] =
	{   
		pass_id = 49, 
		type_count_start1 = {419,10,3600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4909] =
	{   
		pass_id = 49, 
		type_count_start1 = {410,1,5351,0,407,9,3406,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4910] =
	{   
		pass_id = 49, 
		type_count_start1 = {405,1,8500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4911] =
	{   
		pass_id = 49, 
		type_count_start1 = {404,10,4300,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4912] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,7,4298,0,419,3,6138,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4913] =
	{   
		pass_id = 49, 
		type_count_start1 = {413,6,5732,0,401,4,3153,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4914] =
	{   
		pass_id = 49, 
		type_count_start1 = {401,5,4350,0,416,5,4350,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4915] =
	{   
		pass_id = 49, 
		type_count_start1 = {413,15,5352,0,401,5,2944,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4916] =
	{   
		pass_id = 49, 
		type_count_start1 = {404,8,5500,0,407,2,5500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4917] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,6,6000,0,416,4,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4918] =
	{   
		pass_id = 49, 
		type_count_start1 = {419,5,7000,0,401,5,7000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4919] =
	{   
		pass_id = 49, 
		type_count_start1 = {413,6,8000,0,404,4,8000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4920] =
	{   
		pass_id = 49, 
		type_count_start1 = {419,1,16129,0,417,1,8872,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4921] =
	{   
		pass_id = 49, 
		type_count_start1 = {401,10,7000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4922] =
	{   
		pass_id = 49, 
		type_count_start1 = {407,6,7684,0,413,4,10974,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4923] =
	{   
		pass_id = 49, 
		type_count_start1 = {416,9,7273,0,410,1,14546,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4924] =
	{   
		pass_id = 49, 
		type_count_start1 = {404,10,10000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[4925] =
	{   
		pass_id = 49, 
		type_count_start1 = {403,5,7333,0,409,5,9335,0,415,5,13331,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5001] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,10,50,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5002] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,10,100,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5003] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,5,200,0,404,5,200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5004] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,5,371,0,413,5,530,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5005] =
	{   
		pass_id = 50, 
		type_count_start1 = {419,10,800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5006] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,5,865,0,413,5,1235,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5007] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,6,1312,0,416,4,1031,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5008] =
	{   
		pass_id = 50, 
		type_count_start1 = {401,10,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5009] =
	{   
		pass_id = 50, 
		type_count_start1 = {419,7,1676,0,401,3,922,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5010] =
	{   
		pass_id = 50, 
		type_count_start1 = {414,1,4516,0,417,1,2484,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5011] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,10,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5012] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,5,2500,0,404,5,2500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5013] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,7,2779,0,416,3,2183,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5014] =
	{   
		pass_id = 50, 
		type_count_start1 = {419,9,2887,0,410,1,2022,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5015] =
	{   
		pass_id = 50, 
		type_count_start1 = {401,10,2078,0,407,10,2645,0,413,10,3778,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5016] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,10,3300,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5017] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,8,3408,0,419,2,4867,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5018] =
	{   
		pass_id = 50, 
		type_count_start1 = {416,10,3300,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5019] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,10,4050,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5020] =
	{   
		pass_id = 50, 
		type_count_start1 = {401,5,3333,0,426,1,8332,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5021] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,5,3707,0,413,5,5294,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5022] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,5,3912,0,419,5,5587,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5023] =
	{   
		pass_id = 50, 
		type_count_start1 = {407,10,5000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5024] =
	{   
		pass_id = 50, 
		type_count_start1 = {404,6,5469,0,416,4,4296,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5025] =
	{   
		pass_id = 50, 
		type_count_start1 = {427,1,8000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5101] =
	{   
		pass_id = 51, 
		type_count_start1 = {401,10,200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5102] =
	{   
		pass_id = 51, 
		type_count_start1 = {416,10,400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5103] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,10,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5104] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,10,1400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5105] =
	{   
		pass_id = 51, 
		type_count_start1 = {413,10,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5106] =
	{   
		pass_id = 51, 
		type_count_start1 = {419,10,2400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5107] =
	{   
		pass_id = 51, 
		type_count_start1 = {410,2,2100,0,407,8,2100,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5108] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,6,2561,0,413,4,3657,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5109] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,5,2913,0,401,5,2288,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5110] =
	{   
		pass_id = 51, 
		type_count_start1 = {405,1,7500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5111] =
	{   
		pass_id = 51, 
		type_count_start1 = {416,7,2600,0,401,3,2600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5112] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,7,3421,0,416,3,2687,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5113] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,6,3074,0,419,4,4390,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5114] =
	{   
		pass_id = 51, 
		type_count_start1 = {413,5,4200,0,419,5,4200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5115] =
	{   
		pass_id = 51, 
		type_count_start1 = {411,2,3667,0,404,10,3667,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5116] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,10,4500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5117] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,8,4800,0,404,2,4800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5118] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,10,5200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5119] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,6,5469,0,401,4,4296,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5120] =
	{   
		pass_id = 51, 
		type_count_start1 = {414,1,14193,0,402,1,7807,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5121] =
	{   
		pass_id = 51, 
		type_count_start1 = {419,8,5319,0,410,2,3724,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5122] =
	{   
		pass_id = 51, 
		type_count_start1 = {407,7,4800,0,410,3,4800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5123] =
	{   
		pass_id = 51, 
		type_count_start1 = {416,6,4147,0,410,4,5279,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5124] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,10,5500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5125] =
	{   
		pass_id = 51, 
		type_count_start1 = {413,5,7499,0,407,10,5251,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5126] =
	{   
		pass_id = 51, 
		type_count_start1 = {419,10,6200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5127] =
	{   
		pass_id = 51, 
		type_count_start1 = {404,5,6000,0,407,5,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5128] =
	{   
		pass_id = 51, 
		type_count_start1 = {413,6,7926,0,401,4,4360,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5129] =
	{   
		pass_id = 51, 
		type_count_start1 = {401,7,6000,0,416,3,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5130] =
	{   
		pass_id = 51, 
		type_count_start1 = {420,1,15553,0,408,1,10891,0,417,1,8555,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5201] =
	{   
		pass_id = 52, 
		type_count_start1 = {407,15,1,0}, 
		type_count_start2 = {404,15,1,0}
	}
LevelMonster4Config[5202] =
	{   
		pass_id = 52, 
		type_count_start1 = {404,10,1,0}, 
		type_count_start2 = {407,10,1,0}
	}
LevelMonster4Config[5203] =
	{   
		pass_id = 52, 
		type_count_start1 = {407,5,200,0,404,5,200,0}, 
		type_count_start2 = {404,5,200,0,407,5,200,0}
	}
LevelMonster4Config[5204] =
	{   
		pass_id = 52, 
		type_count_start1 = {413,10,400,0}, 
		type_count_start2 = {419,10,400,0}
	}
LevelMonster4Config[5205] =
	{   
		pass_id = 52, 
		type_count_start1 = {404,5,494,0,419,5,705,0}, 
		type_count_start2 = {407,5,494,0,413,5,705,0}
	}
LevelMonster4Config[5206] =
	{   
		pass_id = 52, 
		type_count_start1 = {416,10,600,0}, 
		type_count_start2 = {401,10,600,0}
	}
LevelMonster4Config[5207] =
	{   
		pass_id = 52, 
		type_count_start1 = {401,10,700,0}, 
		type_count_start2 = {416,10,700,0}
	}
LevelMonster4Config[5208] =
	{   
		pass_id = 52, 
		type_count_start1 = {407,8,1254,0,416,2,985,0}, 
		type_count_start2 = {404,6,1203,0,416,4,945,0}
	}
LevelMonster4Config[5209] =
	{   
		pass_id = 52, 
		type_count_start1 = {404,8,1290,0,413,2,1842,0}, 
		type_count_start2 = {419,2,1842,0,404,8,1290,0}
	}
LevelMonster4Config[5210] =
	{   
		pass_id = 52, 
		type_count_start1 = {420,1,5000,0}, 
		type_count_start2 = {414,1,5000,0}
	}
LevelMonster4Config[5211] =
	{   
		pass_id = 52, 
		type_count_start1 = {407,10,1800,0}, 
		type_count_start2 = {407,10,1800,0}
	}
LevelMonster4Config[5212] =
	{   
		pass_id = 52, 
		type_count_start1 = {410,2,2000,0,404,8,2000,0}, 
		type_count_start2 = {413,10,2200,0}
	}
LevelMonster4Config[5213] =
	{   
		pass_id = 52, 
		type_count_start1 = {419,10,2200,0}, 
		type_count_start2 = {410,2,2200,0,404,8,2200,0}
	}
LevelMonster4Config[5214] =
	{   
		pass_id = 52, 
		type_count_start1 = {419,5,2700,0,413,5,2700,0}, 
		type_count_start2 = {413,5,2700,0,419,5,2700,0}
	}
LevelMonster4Config[5215] =
	{   
		pass_id = 52, 
		type_count_start1 = {429,1,7000,9000}, 
		type_count_start2 = {429,1,7000,9000}
	}
LevelMonster4Config[5216] =
	{   
		pass_id = 52, 
		type_count_start1 = {401,10,2600,0}, 
		type_count_start2 = {416,10,2600,0}
	}
LevelMonster4Config[5217] =
	{   
		pass_id = 52, 
		type_count_start1 = {407,7,3207,0,416,3,2519,0}, 
		type_count_start2 = {404,7,3207,0,401,3,2519,0}
	}
LevelMonster4Config[5218] =
	{   
		pass_id = 52, 
		type_count_start1 = {404,6,2903,0,413,4,4146,0}, 
		type_count_start2 = {407,6,2903,0,413,4,4146,0}
	}
LevelMonster4Config[5219] =
	{   
		pass_id = 52, 
		type_count_start1 = {404,10,3600,0}, 
		type_count_start2 = {407,10,3600,0}
	}
LevelMonster4Config[5220] =
	{   
		pass_id = 52, 
		type_count_start1 = {408,5,5667,0,430,1,5667,6000}, 
		type_count_start2 = {406,5,4882,0,430,1,9588,6000}
	}
LevelMonster4Config[5301] =
	{   
		pass_id = 53, 
		type_count_start1 = {419,10,50,0,407,10,50,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5302] =
	{   
		pass_id = 53, 
		type_count_start1 = {404,10,100,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5303] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,5,350,0,404,5,350,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5304] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,6,600,0,416,4,600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5305] =
	{   
		pass_id = 53, 
		type_count_start1 = {404,6,853.789403085178,0,413,4,1219.61665357423,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5306] =
	{   
		pass_id = 53, 
		type_count_start1 = {401,10,830,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5307] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,7,1281.911,0,416,3,1007.47208462766,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5308] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,7,1417.89070657849,0,419,3,2025.07776904949,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5309] =
	{   
		pass_id = 53, 
		type_count_start1 = {419,6,2316.132,0,401,4,1274.48349879259,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5310] =
	{   
		pass_id = 53, 
		type_count_start1 = {414,2,2537.089,0,416,10,1992.66698549338,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5311] =
	{   
		pass_id = 53, 
		type_count_start1 = {413,6,2600,0,419,4,2600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5312] =
	{   
		pass_id = 53, 
		type_count_start1 = {419,3,3890.02356637863,0,407,7,2475.8232177587,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5313] =
	{   
		pass_id = 53, 
		type_count_start1 = {413,5,3734,0,401,5,1866.66666666667,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5314] =
	{   
		pass_id = 53, 
		type_count_start1 = {404,10,3200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5315] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,10,3333.33333333333,0,411,2,3333,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5316] =
	{   
		pass_id = 53, 
		type_count_start1 = {416,6,3200,0,401,4,3200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5317] =
	{   
		pass_id = 53, 
		type_count_start1 = {413,10,3800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5318] =
	{   
		pass_id = 53, 
		type_count_start1 = {419,7,4392.288,0,416,3,2416.38051634236,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5319] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,6,4200,0,404,4,4200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5320] =
	{   
		pass_id = 53, 
		type_count_start1 = {414,1,8500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5321] =
	{   
		pass_id = 53, 
		type_count_start1 = {404,10,4600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5322] =
	{   
		pass_id = 53, 
		type_count_start1 = {410,2,7500,3000,416,8,3750,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5323] =
	{   
		pass_id = 53, 
		type_count_start1 = {419,6,5200,0,413,4,5200,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5324] =
	{   
		pass_id = 53, 
		type_count_start1 = {407,5,5823.975,0,401,5,4575.45094588649,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5325] =
	{   
		pass_id = 53, 
		type_count_start1 = {406,3,8000,0,418,2,8000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5401] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,10,53.5393076674215,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5402] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,7,80,0,407,3,80,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5403] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,6,170.757880617036,0,413,4,244.208955223881,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5404] =
	{   
		pass_id = 54, 
		type_count_start1 = {419,10,600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5405] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,8,800,0,410,2,800,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5406] =
	{   
		pass_id = 54, 
		type_count_start1 = {416,10,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5407] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,6,1421.941,0,401,4,1117.03041759753,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5408] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,7,1709.639,0,416,3,1343.29611283687,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5409] =
	{   
		pass_id = 54, 
		type_count_start1 = {413,6,2000,0,419,4,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5410] =
	{   
		pass_id = 54, 
		type_count_start1 = {408,10,4500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5411] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,10,2600,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5412] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,10,3000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5413] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,5,3400,0,407,5,3400,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5414] =
	{   
		pass_id = 54, 
		type_count_start1 = {413,7,3735.99274705349,0,410,3,2616.02200220022,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5415] =
	{   
		pass_id = 54, 
		type_count_start1 = {420,6,7386.24980361351,0,405,4,5171.5625,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5416] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,10,3800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5417] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,6,4375.301,0,416,4,3437.01666953085,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5418] =
	{   
		pass_id = 54, 
		type_count_start1 = {401,10,3800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5419] =
	{   
		pass_id = 54, 
		type_count_start1 = {413,8,4679.95758051846,0,404,2,3277.4722059684,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5420] =
	{   
		pass_id = 54, 
		type_count_start1 = {414,5,10322.604,0,417,5,5677.7856635912,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5421] =
	{   
		pass_id = 54, 
		type_count_start1 = {404,7,4253.67211973547,0,419,3,6075.23330714847,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5422] =
	{   
		pass_id = 54, 
		type_count_start1 = {416,10,4500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5423] =
	{   
		pass_id = 54, 
		type_count_start1 = {401,7,4800,0,416,3,4800,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5424] =
	{   
		pass_id = 54, 
		type_count_start1 = {407,9,3571.42857142857,0,410,5,3571,3000}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5425] =
	{   
		pass_id = 54, 
		type_count_start1 = {415,10,10000,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5501] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5502] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5503] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5504] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5505] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5506] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5507] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5508] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5509] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5510] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5511] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5512] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5513] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5514] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5515] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5516] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5517] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5518] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5519] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5520] =
	{   
		pass_id = 55, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5601] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5602] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5603] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5604] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5605] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5606] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5607] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5608] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5609] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5610] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5611] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5612] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5613] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5614] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5615] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5616] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5617] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5618] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5619] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5620] =
	{   
		pass_id = 56, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5701] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5702] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5703] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5704] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5705] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5706] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5707] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5708] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5709] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5710] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5711] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5712] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5713] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5714] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5715] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5716] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5717] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5718] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5719] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5720] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5721] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5722] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5723] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5724] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5725] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5726] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5727] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5728] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5729] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5730] =
	{   
		pass_id = 57, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5801] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5802] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5803] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5804] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5805] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5806] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5807] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5808] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5809] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5810] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5811] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5812] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5813] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5814] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5815] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5816] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5817] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5818] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5819] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5820] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5821] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5822] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5823] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5824] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5825] =
	{   
		pass_id = 58, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5901] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5902] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5903] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5904] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5905] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5906] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5907] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5908] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5909] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5910] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5911] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[5912] =
	{   
		pass_id = 59, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6001] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6002] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6003] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6004] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6005] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6006] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6007] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6008] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6009] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6010] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6011] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6012] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6013] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6014] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6015] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6016] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6017] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6018] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6019] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6020] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6021] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6022] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6023] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6024] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6025] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6026] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6027] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6028] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6029] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster4Config[6030] =
	{   
		pass_id = 60, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}


function LevelMonster4Config.pass_id(id)
	return LevelMonster4Config[id].pass_id
end

function LevelMonster4Config.type_count_start1(id)
	return LevelMonster4Config[id].type_count_start1
end

function LevelMonster4Config.type_count_start2(id)
	return LevelMonster4Config[id].type_count_start2
end

        