-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-02 12:02:31
MusicSoundConfig = {}
MusicSoundConfig[101] =
	{   
		id = 101, 
		filename = "BGMusic.mp3", 
		type = 1
	}
MusicSoundConfig[102] =
	{   
		id = 102, 
		filename = "BGTheme01.mp3", 
		type = 1
	}
MusicSoundConfig[103] =
	{   
		id = 103, 
		filename = "BGTheme02.mp3", 
		type = 1
	}
MusicSoundConfig[104] =
	{   
		id = 104, 
		filename = "BGTheme03.mp3", 
		type = 1
	}
MusicSoundConfig[105] =
	{   
		id = 105, 
		filename = "BGTheme04.mp3", 
		type = 1
	}
MusicSoundConfig[201] =
	{   
		id = 201, 
		filename = "a_a_xiabing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[202] =
	{   
		id = 202, 
		filename = "a_xiabing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[203] =
	{   
		id = 203, 
		filename = "a_xiejiang_die1.mp3", 
		type = 2
	}
MusicSoundConfig[204] =
	{   
		id = 204, 
		filename = "a_xiejiang_die2.mp3", 
		type = 2
	}
MusicSoundConfig[205] =
	{   
		id = 205, 
		filename = "a_guichengxiang_die1.mp3", 
		type = 2
	}
MusicSoundConfig[206] =
	{   
		id = 206, 
		filename = "a_guichengxiang_die2.mp3", 
		type = 2
	}
MusicSoundConfig[207] =
	{   
		id = 207, 
		filename = "a_hailuo_die1.mp3", 
		type = 2
	}
MusicSoundConfig[208] =
	{   
		id = 208, 
		filename = "a_hailuo_die2.mp3", 
		type = 2
	}
MusicSoundConfig[209] =
	{   
		id = 209, 
		filename = "a_zhangyu_die1.mp3", 
		type = 2
	}
MusicSoundConfig[210] =
	{   
		id = 210, 
		filename = "a_zhangyu_die2.mp3", 
		type = 2
	}
MusicSoundConfig[211] =
	{   
		id = 211, 
		filename = "a_haixing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[212] =
	{   
		id = 212, 
		filename = "a_haixing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[213] =
	{   
		id = 213, 
		filename = "a_lanjing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[214] =
	{   
		id = 214, 
		filename = "a_lanjing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[215] =
	{   
		id = 215, 
		filename = "xiaohouzi_die.mp3", 
		type = 2
	}
MusicSoundConfig[216] =
	{   
		id = 216, 
		filename = "zhizhujing_die.mp3", 
		type = 2
	}
MusicSoundConfig[217] =
	{   
		id = 217, 
		filename = "taibai_die.mp3", 
		type = 2
	}
MusicSoundConfig[218] =
	{   
		id = 218, 
		filename = "leizhenzi_die.mp3", 
		type = 2
	}
MusicSoundConfig[219] =
	{   
		id = 219, 
		filename = "sunwukong_die.mp3", 
		type = 2
	}
MusicSoundConfig[220] =
	{   
		id = 220, 
		filename = "longwang_die.mp3", 
		type = 2
	}
MusicSoundConfig[221] =
	{   
		id = 221, 
		filename = "b_heiwuchang_die1.mp3", 
		type = 2
	}
MusicSoundConfig[222] =
	{   
		id = 222, 
		filename = "b_heiwuchang_die2.mp3", 
		type = 2
	}
MusicSoundConfig[223] =
	{   
		id = 223, 
		filename = "b_baiwuchang_die1.mp3", 
		type = 2
	}
MusicSoundConfig[224] =
	{   
		id = 224, 
		filename = "b_baiwuchang_die2.mp3", 
		type = 2
	}
MusicSoundConfig[225] =
	{   
		id = 225, 
		filename = "b_diting_die1.mp3", 
		type = 2
	}
MusicSoundConfig[226] =
	{   
		id = 226, 
		filename = "b_diting_die2.mp3", 
		type = 2
	}
MusicSoundConfig[227] =
	{   
		id = 227, 
		filename = "b_niutou_die1.mp3", 
		type = 2
	}
MusicSoundConfig[228] =
	{   
		id = 228, 
		filename = "b_niutou_die2.mp3", 
		type = 2
	}
MusicSoundConfig[229] =
	{   
		id = 229, 
		filename = "b_mamian_die1.mp3", 
		type = 2
	}
MusicSoundConfig[230] =
	{   
		id = 230, 
		filename = "b_mamian_die2.mp3", 
		type = 2
	}
MusicSoundConfig[231] =
	{   
		id = 231, 
		filename = "b_guihun_die1.mp3", 
		type = 2
	}
MusicSoundConfig[232] =
	{   
		id = 232, 
		filename = "b_guihun_die2.mp3", 
		type = 2
	}
MusicSoundConfig[233] =
	{   
		id = 233, 
		filename = "b_kulouren_die1.mp3", 
		type = 2
	}
MusicSoundConfig[234] =
	{   
		id = 234, 
		filename = "b_kulouren_die2.mp3", 
		type = 2
	}
MusicSoundConfig[235] =
	{   
		id = 235, 
		filename = "zhubajie_die.mp3", 
		type = 2
	}
MusicSoundConfig[236] =
	{   
		id = 236, 
		filename = "honghaier_die.mp3", 
		type = 2
	}
MusicSoundConfig[237] =
	{   
		id = 237, 
		filename = "change_die.mp3", 
		type = 2
	}
MusicSoundConfig[238] =
	{   
		id = 238, 
		filename = "nezha_die.mp3", 
		type = 2
	}
MusicSoundConfig[239] =
	{   
		id = 239, 
		filename = "xiaonvlong_die.mp3", 
		type = 2
	}
MusicSoundConfig[240] =
	{   
		id = 240, 
		filename = "yanwang_die.mp3", 
		type = 2
	}
MusicSoundConfig[241] =
	{   
		id = 241, 
		filename = "c_tianbing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[242] =
	{   
		id = 242, 
		filename = "c_tianbing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[243] =
	{   
		id = 243, 
		filename = "c_xiannv_die1.mp3", 
		type = 2
	}
MusicSoundConfig[244] =
	{   
		id = 244, 
		filename = "c_xiannv_die2.mp3", 
		type = 2
	}
MusicSoundConfig[245] =
	{   
		id = 245, 
		filename = "c_xiaotianquan_die1.mp3", 
		type = 2
	}
MusicSoundConfig[246] =
	{   
		id = 246, 
		filename = "c_xiaotianquan_die2.mp3", 
		type = 2
	}
MusicSoundConfig[247] =
	{   
		id = 247, 
		filename = "c_julingshen_die1.mp3", 
		type = 2
	}
MusicSoundConfig[248] =
	{   
		id = 248, 
		filename = "c_julingshen_die2.mp3", 
		type = 2
	}
MusicSoundConfig[249] =
	{   
		id = 249, 
		filename = "c_yutu_die1.mp3", 
		type = 2
	}
MusicSoundConfig[250] =
	{   
		id = 250, 
		filename = "c_yutu_die2.mp3", 
		type = 2
	}
MusicSoundConfig[251] =
	{   
		id = 251, 
		filename = "c_tianma_die1.mp3", 
		type = 2
	}
MusicSoundConfig[252] =
	{   
		id = 252, 
		filename = "c_tianma_die2.mp3", 
		type = 2
	}
MusicSoundConfig[253] =
	{   
		id = 253, 
		filename = "c_huli_die1.mp3", 
		type = 2
	}
MusicSoundConfig[254] =
	{   
		id = 254, 
		filename = "c_huli_die2.mp3", 
		type = 2
	}
MusicSoundConfig[255] =
	{   
		id = 255, 
		filename = "niumowang_die.mp3", 
		type = 2
	}
MusicSoundConfig[256] =
	{   
		id = 256, 
		filename = "chijiaodaxian_die.mp3", 
		type = 2
	}
MusicSoundConfig[257] =
	{   
		id = 257, 
		filename = "shawujing_die.mp3", 
		type = 2
	}
MusicSoundConfig[258] =
	{   
		id = 258, 
		filename = "tuotatianwang_die.mp3", 
		type = 2
	}
MusicSoundConfig[259] =
	{   
		id = 259, 
		filename = "erlangsheng_die.mp3", 
		type = 2
	}
MusicSoundConfig[260] =
	{   
		id = 260, 
		filename = "d_laoshu_die1.mp3", 
		type = 2
	}
MusicSoundConfig[261] =
	{   
		id = 261, 
		filename = "d_laoshu_die2.mp3", 
		type = 2
	}
MusicSoundConfig[262] =
	{   
		id = 262, 
		filename = "d_laohu_die1.mp3", 
		type = 2
	}
MusicSoundConfig[263] =
	{   
		id = 263, 
		filename = "d_laohu_die2.mp3", 
		type = 2
	}
MusicSoundConfig[264] =
	{   
		id = 264, 
		filename = "d_heibao_die1.mp3", 
		type = 2
	}
MusicSoundConfig[265] =
	{   
		id = 265, 
		filename = "d_heibao_die2.mp3", 
		type = 2
	}
MusicSoundConfig[266] =
	{   
		id = 266, 
		filename = "d_shujing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[267] =
	{   
		id = 267, 
		filename = "d_shujing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[268] =
	{   
		id = 268, 
		filename = "d_xiong_die1.mp3", 
		type = 2
	}
MusicSoundConfig[269] =
	{   
		id = 269, 
		filename = "d_xiong_die2.mp3", 
		type = 2
	}
MusicSoundConfig[270] =
	{   
		id = 270, 
		filename = "d_she_die1.mp3", 
		type = 2
	}
MusicSoundConfig[271] =
	{   
		id = 271, 
		filename = "d_she_die2.mp3", 
		type = 2
	}
MusicSoundConfig[272] =
	{   
		id = 272, 
		filename = "d_xingxing_die1.mp3", 
		type = 2
	}
MusicSoundConfig[273] =
	{   
		id = 273, 
		filename = "d_xingxing_die2.mp3", 
		type = 2
	}
MusicSoundConfig[274] =
	{   
		id = 274, 
		filename = "huangfengguai_die.mp3", 
		type = 2
	}
MusicSoundConfig[275] =
	{   
		id = 275, 
		filename = "xiezijing_die.mp3", 
		type = 2
	}
MusicSoundConfig[276] =
	{   
		id = 276, 
		filename = "tieshangongzhu_die.mp3", 
		type = 2
	}
MusicSoundConfig[277] =
	{   
		id = 277, 
		filename = "jiutouchong_die.mp3", 
		type = 2
	}
MusicSoundConfig[278] =
	{   
		id = 278, 
		filename = "linggandawang_die.mp3", 
		type = 2
	}
MusicSoundConfig[301] =
	{   
		id = 301, 
		filename = "zhangyu_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[302] =
	{   
		id = 302, 
		filename = "zhangyu_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[303] =
	{   
		id = 303, 
		filename = "xiaohouzi_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[304] =
	{   
		id = 304, 
		filename = "xiaohouzi_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[305] =
	{   
		id = 305, 
		filename = "zhizhujing_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[306] =
	{   
		id = 306, 
		filename = "zhizhujing_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[307] =
	{   
		id = 307, 
		filename = "taibai_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[308] =
	{   
		id = 308, 
		filename = "taibai_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[309] =
	{   
		id = 309, 
		filename = "leizhenzi_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[310] =
	{   
		id = 310, 
		filename = "leizhenzi_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[311] =
	{   
		id = 311, 
		filename = "sunwukong_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[312] =
	{   
		id = 312, 
		filename = "sunwukong_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[313] =
	{   
		id = 313, 
		filename = "longwang_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[314] =
	{   
		id = 314, 
		filename = "longwang_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[315] =
	{   
		id = 315, 
		filename = "guihun_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[316] =
	{   
		id = 316, 
		filename = "guihun_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[317] =
	{   
		id = 317, 
		filename = "zhubajie_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[318] =
	{   
		id = 318, 
		filename = "zhubajie_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[319] =
	{   
		id = 319, 
		filename = "honghaier_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[320] =
	{   
		id = 320, 
		filename = "honghaier_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[321] =
	{   
		id = 321, 
		filename = "change_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[322] =
	{   
		id = 322, 
		filename = "change_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[323] =
	{   
		id = 323, 
		filename = "nezha_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[324] =
	{   
		id = 324, 
		filename = "nezha_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[325] =
	{   
		id = 325, 
		filename = "xiaolongnv_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[326] =
	{   
		id = 326, 
		filename = "xiaolongnv_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[327] =
	{   
		id = 327, 
		filename = "yanwang_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[328] =
	{   
		id = 328, 
		filename = "yanwang_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[329] =
	{   
		id = 329, 
		filename = "julingshen_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[330] =
	{   
		id = 330, 
		filename = "julingshen_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[331] =
	{   
		id = 331, 
		filename = "niumowang_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[332] =
	{   
		id = 332, 
		filename = "niumowang_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[333] =
	{   
		id = 333, 
		filename = "chijiaodaxian_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[334] =
	{   
		id = 334, 
		filename = "chijiaodaxian_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[335] =
	{   
		id = 335, 
		filename = "shawujing_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[336] =
	{   
		id = 336, 
		filename = "shawujing_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[337] =
	{   
		id = 337, 
		filename = "tuotatianwang_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[338] =
	{   
		id = 338, 
		filename = "tuotatianwang_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[339] =
	{   
		id = 339, 
		filename = "erlangshen_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[340] =
	{   
		id = 340, 
		filename = "erlangshen_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[341] =
	{   
		id = 341, 
		filename = "shujing_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[342] =
	{   
		id = 342, 
		filename = "shujing_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[343] =
	{   
		id = 343, 
		filename = "xiezijing_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[344] =
	{   
		id = 344, 
		filename = "xiezijing_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[345] =
	{   
		id = 345, 
		filename = "tieshangongzhu_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[346] =
	{   
		id = 346, 
		filename = "tieshangongzhu_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[347] =
	{   
		id = 347, 
		filename = "jiutouchong_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[348] =
	{   
		id = 348, 
		filename = "jiutouchong_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[349] =
	{   
		id = 349, 
		filename = "linggandawang_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[350] =
	{   
		id = 350, 
		filename = "linggandawang_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[351] =
	{   
		id = 351, 
		filename = "huangfengguai_attack_start.mp3", 
		type = 3
	}
MusicSoundConfig[352] =
	{   
		id = 352, 
		filename = "huangfengguai_attack_end.mp3", 
		type = 3
	}
MusicSoundConfig[401] =
	{   
		id = 401, 
		filename = "ClockStart.mp3", 
		type = 4
	}
MusicSoundConfig[402] =
	{   
		id = 402, 
		filename = "ClockEnd.mp3", 
		type = 4
	}
MusicSoundConfig[403] =
	{   
		id = 403, 
		filename = "ClickError.mp3", 
		type = 4
	}
MusicSoundConfig[404] =
	{   
		id = 404, 
		filename = "click_trench.mp3", 
		type = 4
	}
MusicSoundConfig[405] =
	{   
		id = 405, 
		filename = "click_trench.mp3", 
		type = 4
	}
MusicSoundConfig[406] =
	{   
		id = 406, 
		filename = "ClickHero.mp3", 
		type = 4
	}
MusicSoundConfig[407] =
	{   
		id = 407, 
		filename = "ClickCancel.mp3", 
		type = 4
	}
MusicSoundConfig[408] =
	{   
		id = 408, 
		filename = "HeroJoin.mp3", 
		type = 4
	}
MusicSoundConfig[409] =
	{   
		id = 409, 
		filename = "heroRecover.mp3", 
		type = 4
	}
MusicSoundConfig[410] =
	{   
		id = 410, 
		filename = "HeroUpgrade.mp3", 
		type = 4
	}
MusicSoundConfig[411] =
	{   
		id = 411, 
		filename = "HeroRemove.mp3", 
		type = 4
	}
MusicSoundConfig[412] =
	{   
		id = 412, 
		filename = "HeroBuild.mp3", 
		type = 4
	}
MusicSoundConfig[413] =
	{   
		id = 413, 
		filename = "MonsterAppearance.mp3", 
		type = 4
	}
MusicSoundConfig[414] =
	{   
		id = 414, 
		filename = "ShootSelect.mp3", 
		type = 4
	}
MusicSoundConfig[415] =
	{   
		id = 415, 
		filename = "rotate.mp3", 
		type = 4
	}
MusicSoundConfig[416] =
	{   
		id = 416, 
		filename = "bombExplosion.mp3", 
		type = 4
	}
MusicSoundConfig[417] =
	{   
		id = 417, 
		filename = "FinishTask.mp3", 
		type = 4
	}
MusicSoundConfig[418] =
	{   
		id = 418, 
		filename = "finishAllTask.mp3", 
		type = 4
	}
MusicSoundConfig[419] =
	{   
		id = 419, 
		filename = "cleanAllBuild.mp3", 
		type = 4
	}
MusicSoundConfig[420] =
	{   
		id = 420, 
		filename = "FinalWave.mp3", 
		type = 4
	}
MusicSoundConfig[421] =
	{   
		id = 421, 
		filename = "finalwave.mp3", 
		type = 4
	}
MusicSoundConfig[422] =
	{   
		id = 422, 
		filename = "prop1.mp3", 
		type = 4
	}
MusicSoundConfig[423] =
	{   
		id = 423, 
		filename = "prop2.mp3", 
		type = 4
	}
MusicSoundConfig[424] =
	{   
		id = 424, 
		filename = "prop3.mp3", 
		type = 4
	}
MusicSoundConfig[425] =
	{   
		id = 425, 
		filename = "prop4.mp3", 
		type = 4
	}
MusicSoundConfig[426] =
	{   
		id = 426, 
		filename = "prop5.mp3", 
		type = 4
	}
MusicSoundConfig[427] =
	{   
		id = 427, 
		filename = "button.mp3", 
		type = 4
	}
MusicSoundConfig[428] =
	{   
		id = 428, 
		filename = "switch.mp3", 
		type = 4
	}
MusicSoundConfig[429] =
	{   
		id = 429, 
		filename = "getStar.mp3", 
		type = 4
	}
MusicSoundConfig[430] =
	{   
		id = 430, 
		filename = "seal.mp3", 
		type = 4
	}
MusicSoundConfig[431] =
	{   
		id = 431, 
		filename = "consumeStamina.mp3", 
		type = 4
	}
MusicSoundConfig[432] =
	{   
		id = 432, 
		filename = "Select.mp3", 
		type = 4
	}
MusicSoundConfig[433] =
	{   
		id = 433, 
		filename = "consumeStamina.mp3", 
		type = 4
	}
MusicSoundConfig[434] =
	{   
		id = 434, 
		filename = "Win.mp3", 
		type = 4
	}
MusicSoundConfig[435] =
	{   
		id = 435, 
		filename = "Lose.mp3", 
		type = 4
	}


function MusicSoundConfig.id(id)
	return MusicSoundConfig[id].id
end

function MusicSoundConfig.filename(id)
	return MusicSoundConfig[id].filename
end

function MusicSoundConfig.type(id)
	return MusicSoundConfig[id].type
end

        