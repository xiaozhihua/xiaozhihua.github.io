-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-10 17:57:07
LevelMonster3Config = {}
LevelMonster3Config[3101] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,1,80,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3102] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,120,0,307,2,160,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3103] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,200,0,307,2,240,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3104] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,280,0,307,5,320,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3105] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,360,0,319,2,400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3106] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,440,0,319,4,480,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3107] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,520,0,319,5,560,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3108] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,600,0,319,6,640,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3109] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,680,0,313,2,520,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3110] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,760,0,313,4,600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3111] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,840,0,313,5,680,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3112] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,920,0,313,6,760,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3113] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,1000,0,316,8,840,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3114] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,1080,0,316,6,920,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3115] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,5,1160,0,316,5,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3116] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,1240,0,316,4,1080,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3117] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,10,1140,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3118] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,8,1180,0,316,2,1320,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3119] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,6,1360,0,316,4,1400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3120] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,12000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3201] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,10,100,0}, 
		type_count_start2 = {304,10,100,0}
	}
LevelMonster3Config[3202] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,170,0,301,2,240,0}, 
		type_count_start2 = {307,8,170,0,301,2,240,0}
	}
LevelMonster3Config[3203] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,310,0,301,4,380,0}, 
		type_count_start2 = {307,6,310,0,301,4,380,0}
	}
LevelMonster3Config[3204] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,450,0,301,5,520,0}, 
		type_count_start2 = {307,5,450,0,301,5,520,0}
	}
LevelMonster3Config[3205] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,590,0,319,2,660,0}, 
		type_count_start2 = {301,8,590,0,319,2,660,0}
	}
LevelMonster3Config[3206] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,730,0,319,4,800,0}, 
		type_count_start2 = {301,6,730,0,319,4,800,0}
	}
LevelMonster3Config[3207] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,870,0,319,5,940,0}, 
		type_count_start2 = {301,5,870,0,319,5,940,0}
	}
LevelMonster3Config[3208] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,1010,0,319,6,1080,0}, 
		type_count_start2 = {301,4,1010,0,319,6,1080,0}
	}
LevelMonster3Config[3209] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,1150,0,316,2,820,0}, 
		type_count_start2 = {304,8,1150,0,316,2,820,0}
	}
LevelMonster3Config[3210] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,1290,0,316,4,900,0}, 
		type_count_start2 = {304,6,1290,0,316,4,900,0}
	}
LevelMonster3Config[3211] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,1430,0,316,5,1050,0}, 
		type_count_start2 = {304,5,1430,0,316,5,1050,0}
	}
LevelMonster3Config[3212] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1570,0,316,6,1230,0}, 
		type_count_start2 = {304,4,1570,0,316,6,1230,0}
	}
LevelMonster3Config[3213] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,1700,0,313,8,1350,0}, 
		type_count_start2 = {319,2,1700,0,313,8,1350,0}
	}
LevelMonster3Config[3214] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,1840,0,313,6,1410,0}, 
		type_count_start2 = {319,4,1840,0,313,6,1410,0}
	}
LevelMonster3Config[3215] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,5,1980,0,313,5,1650,0}, 
		type_count_start2 = {319,5,1980,0,313,5,1650,0}
	}
LevelMonster3Config[3216] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,2120,0,313,4,1790,0}, 
		type_count_start2 = {319,6,2120,0,313,4,1790,0}
	}
LevelMonster3Config[3217] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,10,1900,0}, 
		type_count_start2 = {316,10,1900,0}
	}
LevelMonster3Config[3218] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,8,2040,0,313,2,2270,0}, 
		type_count_start2 = {316,8,2040,0,313,2,2270,0}
	}
LevelMonster3Config[3219] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,6,2180,0,313,4,2410,0}, 
		type_count_start2 = {316,6,2180,0,313,4,2410,0}
	}
LevelMonster3Config[3220] =
	{   
		pass_id = 3, 
		type_count_start1 = {324,1,5000,0}, 
		type_count_start2 = {324,1,5000,0}
	}
LevelMonster3Config[3301] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,10,60,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3302] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,120,0,304,2,180,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3303] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,240,0,304,4,300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3304] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,360,0,304,5,420,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3305] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,480,0,319,2,540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3306] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,600,0,319,4,660,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3307] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,720,0,319,5,780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3308] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,840,0,319,6,900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3309] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,960,0,313,2,1020,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3310] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,1080,0,313,4,1140,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3311] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,1200,0,313,5,1260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3312] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1320,0,313,6,1380,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3313] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,4,1440,0,313,6,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3314] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,8,1560,0,316,2,1620,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3315] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,1680,0,316,4,1740,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3316] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,10,1800,0,316,2,1860,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3317] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,2,1920,0,316,2,1980,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3318] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,4,2040,0,316,6,2100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3319] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,8,2160,0,313,2,2220,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3320] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,10000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3401] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,80,0,307,2,120,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3402] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,120,0,307,4,200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3403] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,280,0,307,5,360,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3404] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,440,0,307,6,520,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3405] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,600,0,319,8,680,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3406] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,760,0,319,8,840,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3407] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,920,0,319,8,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3408] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,1080,0,313,2,860,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3409] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,1240,0,313,4,1020,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3410] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,1400,0,313,5,1180,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3411] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1560,0,313,6,1340,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3412] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,1720,0,313,8,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3413] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,1880,0,304,2,1920,0,307,2,1960,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3414] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,2040,0,304,3,2180,0,307,3,2220,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3415] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2300,0,304,4,2340,0,307,4,2380,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3416] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,2460,0,304,5,2500,0,307,5,2540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3417] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2620,0,307,2,2660,0,313,2,2300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3418] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,2780,0,307,3,2820,0,313,3,2460,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3419] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2940,0,307,4,2980,0,313,4,2620,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3420] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,12000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3501] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,50,0,304,4,50,0,308,1,1200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3502] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,200,0,304,3,250,0,307,4,300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3503] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,350,0,304,2,400,0,307,6,450,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3504] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,500,0,304,3,550,0,307,3,600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3505] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,650,0,301,4,700,0,319,2,750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3506] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,800,0,301,3,850,0,319,4,900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3507] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,950,0,301,2,1050,0,319,6,1100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3508] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1150,0,301,3,1200,0,320,2,1250,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3509] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1300,0,304,4,1350,0,316,2,1100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3510] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,1450,0,304,3,1500,0,316,4,1250,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3511] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,1600,0,304,2,1650,0,316,6,1400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3512] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1750,0,304,3,1800,0,317,3,1850,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3513] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1900,0,319,2,1950,0,316,4,1800,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3514] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,2050,0,319,4,2100,0,316,3,2050,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3515] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,2200,0,319,6,2250,0,316,2,2200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3516] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,2350,0,320,1,2400,0,316,2,2250,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3517] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,2500,0,313,2,2350,0,316,2,2400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3518] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2650,0,313,3,2500,0,316,3,2550,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3519] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,2800,0,313,4,2650,0,316,4,2700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3520] =
	{   
		pass_id = 3, 
		type_count_start1 = {327,1,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3601] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,60,0,307,4,60,0,301,2,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3602] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,170,0,307,3,240,0,301,4,310,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3603] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,380,0,307,2,450,0,301,6,520,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3604] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,590,0,307,3,660,0,301,3,730,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3605] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,800,0,304,4,870,0,319,2,940,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3606] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,1010,0,304,3,1080,0,319,4,1150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3607] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,1220,0,304,2,1290,0,319,6,1360,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3608] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,1430,0,304,2,1500,0,320,2,1570,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3609] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,1640,0,307,4,1710,0,313,2,1780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3610] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,1850,0,307,3,1920,0,313,4,1990,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3611] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,2060,0,307,2,2130,0,313,6,2200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3612] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2270,0,307,3,2340,0,313,3,2410,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3613] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2480,0,319,2,2550,0,313,4,2620,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3614] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,2690,0,319,4,2760,0,313,3,2830,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3615] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,2900,0,319,6,2970,0,313,2,3040,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3616] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,3110,0,320,1,3180,0,313,2,3260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3617] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,3330,0,313,2,3400,0,316,2,3470,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3618] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,3540,0,313,3,3610,0,316,3,3680,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3619] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,3750,0,313,4,3820,0,316,4,3890,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3620] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,3960,0,314,1,5030,0,317,1,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3701] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,100,0,301,4,100,0,304,2,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3702] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,170,0,301,3,240,0,304,4,310,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3703] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,380,0,301,2,450,0,304,6,520,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3704] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,590,0,301,2,660,0,305,1,730,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3705] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,800,0,307,4,870,0,319,2,940,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3706] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,1010,0,307,3,1080,0,319,4,1150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3707] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,1220,0,307,2,1290,0,319,6,1360,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3708] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,1430,0,307,3,1500,0,319,3,1570,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3709] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1640,0,301,4,1710,0,316,2,1780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3710] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,1850,0,301,3,1920,0,316,4,1990,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3711] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2060,0,301,2,2130,0,316,6,2200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3712] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2270,0,301,2,2340,0,317,1,2410,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3713] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2480,0,319,2,2550,0,316,4,2620,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3714] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,2690,0,319,4,2760,0,316,3,2830,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3715] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2900,0,319,6,2970,0,316,2,3040,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3716] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,3110,0,319,3,3180,0,316,3,3250,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3717] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,3320,0,313,2,3390,0,316,2,3460,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3718] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,3530,0,313,3,3600,0,316,3,3670,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3719] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,3740,0,313,4,3810,0,316,4,3880,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3720] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,3950,0,314,1,4520,0,317,1,5000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3801] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,80,0,301,2,80,0,307,2,80,0}, 
		type_count_start2 = {304,2,80,0,301,2,80,0,307,2,80,0}
	}
LevelMonster3Config[3802] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,120,0,301,3,160,0,307,3,200,0}, 
		type_count_start2 = {304,3,120,0,301,3,160,0,307,3,200,0}
	}
LevelMonster3Config[3803] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,240,0,301,4,280,0,307,4,320,0}, 
		type_count_start2 = {304,4,240,0,301,4,280,0,307,4,320,0}
	}
LevelMonster3Config[3804] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,360,0,301,5,400,0,307,5,440,0}, 
		type_count_start2 = {304,5,360,0,301,5,400,0,307,5,440,0}
	}
LevelMonster3Config[3805] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,480,0,301,2,520,0,319,2,560,0}, 
		type_count_start2 = {307,2,480,0,301,2,520,0,319,2,560,0}
	}
LevelMonster3Config[3806] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,600,0,301,3,640,0,319,3,680,0}, 
		type_count_start2 = {307,3,600,0,301,3,640,0,319,3,680,0}
	}
LevelMonster3Config[3807] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,720,0,301,4,760,0,319,4,800,0}, 
		type_count_start2 = {307,4,720,0,301,4,760,0,319,4,800,0}
	}
LevelMonster3Config[3808] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,840,0,301,5,880,0,319,5,920,0}, 
		type_count_start2 = {307,5,840,0,301,5,880,0,319,5,920,0}
	}
LevelMonster3Config[3809] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,960,0,304,2,1000,0,313,2,1040,0}, 
		type_count_start2 = {301,2,960,0,304,2,1000,0,313,2,1040,0}
	}
LevelMonster3Config[3810] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,1080,0,304,3,1120,0,313,3,1160,0}, 
		type_count_start2 = {301,3,1080,0,304,3,1120,0,313,3,1160,0}
	}
LevelMonster3Config[3811] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,1200,0,304,4,1240,0,313,4,1280,0}, 
		type_count_start2 = {301,4,1200,0,304,4,1240,0,313,4,1280,0}
	}
LevelMonster3Config[3812] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,1320,0,304,5,1360,0,313,5,1400,0}, 
		type_count_start2 = {301,5,1320,0,304,5,1360,0,313,5,1400,0}
	}
LevelMonster3Config[3813] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,1440,0,319,2,1480,0,313,2,1520,0}, 
		type_count_start2 = {307,2,1440,0,319,2,1480,0,313,2,1520,0}
	}
LevelMonster3Config[3814] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,1560,0,319,3,1600,0,313,3,1640,0}, 
		type_count_start2 = {307,3,1560,0,319,3,1600,0,313,3,1640,0}
	}
LevelMonster3Config[3815] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1680,0,319,4,1720,0,313,4,1760,0}, 
		type_count_start2 = {307,4,1680,0,319,4,1720,0,313,4,1760,0}
	}
LevelMonster3Config[3816] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,1780,0,319,5,1820,0,313,5,1860,0}, 
		type_count_start2 = {307,5,1780,0,319,5,1820,0,313,5,1860,0}
	}
LevelMonster3Config[3817] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,1900,0,316,2,1940,0,313,2,1980,0}, 
		type_count_start2 = {304,2,1900,0,316,2,1940,0,313,2,1980,0}
	}
LevelMonster3Config[3818] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,2020,0,316,3,2060,0,313,3,2100,0}, 
		type_count_start2 = {304,3,2020,0,316,3,2060,0,313,3,2100,0}
	}
LevelMonster3Config[3819] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2140,0,316,4,2180,0,313,4,2220,0}, 
		type_count_start2 = {304,4,2140,0,316,4,2180,0,313,4,2220,0}
	}
LevelMonster3Config[3820] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,2260,0,316,5,2280,0,313,5,2320,0}, 
		type_count_start2 = {304,5,2260,0,316,5,2280,0,313,5,2320,0}
	}
LevelMonster3Config[3821] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,2360,0,313,2,2400,0,316,2,2440,0}, 
		type_count_start2 = {319,2,2360,0,313,2,2400,0,316,2,2440,0}
	}
LevelMonster3Config[3822] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,3,2480,0,313,3,2520,0,316,3,2560,0}, 
		type_count_start2 = {319,3,2480,0,313,3,2520,0,316,3,2560,0}
	}
LevelMonster3Config[3823] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,2600,0,313,4,2640,0,316,4,2680,0}, 
		type_count_start2 = {319,4,2600,0,313,4,2640,0,316,4,2680,0}
	}
LevelMonster3Config[3824] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,5,2720,0,313,5,2760,0,316,5,2800,0}, 
		type_count_start2 = {319,5,2720,0,313,5,2760,0,316,5,2800,0}
	}
LevelMonster3Config[3825] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,10000,100}, 
		type_count_start2 = {311,1,10000,100}
	}
LevelMonster3Config[3901] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,60,0,304,2,80,0,301,2,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3902] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,175,0,304,3,250,0,301,3,325,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3903] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,400,0,304,4,475,0,301,4,550,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3904] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,625,0,304,5,700,0,301,5,775,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3905] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,850,0,304,2,925,0,319,2,1050,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3906] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,1125,0,304,3,1200,0,319,3,1275,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3907] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,1350,0,304,4,1425,0,319,4,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3908] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,1575,0,304,5,1650,0,319,5,1725,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3909] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,1800,0,307,2,1875,0,316,2,1750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3910] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,2025,0,307,3,2100,0,316,3,1975,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3911] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2250,0,307,4,2325,0,316,4,2200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3912] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,2475,0,307,5,2550,0,316,5,2425,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3913] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,2700,0,319,2,2775,0,316,2,2650,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3914] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,2925,0,319,3,3000,0,316,3,2875,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3915] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,3150,0,319,4,3225,0,316,4,3100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3916] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,3375,0,319,5,3450,0,316,5,3325,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3917] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,3600,0,313,2,3275,0,316,2,3350,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3918] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,3825,0,313,3,3500,0,316,3,3575,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3919] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,4050,0,313,4,3725,0,316,4,3800,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3920] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,4275,0,313,5,3950,0,316,5,4025,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3921] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,4500,0,316,2,4175,0,313,2,4250,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3922] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,3,4725,0,316,3,4400,0,313,3,4475,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3923] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,4950,0,316,4,4625,0,313,4,4700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3924] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,5,5175,0,316,5,4650,0,313,5,4725,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[3925] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,16000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4001] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,100,0,307,2,100,0,304,2,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4002] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,160,0,307,3,220,0,304,3,280,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4003] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,340,0,307,4,400,0,304,4,460,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4004] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,520,0,307,5,580,0,304,5,640,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4005] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,700,0,304,2,760,0,319,2,820,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4006] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,880,0,304,3,940,0,319,3,1000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4007] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1060,0,304,4,1120,0,319,4,1180,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4008] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,1240,0,304,5,1300,0,319,5,1360,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4009] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,1420,0,301,2,1480,0,313,2,1540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4010] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,1600,0,301,3,1660,0,313,3,1720,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4011] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1780,0,301,4,1840,0,313,4,1900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4012] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,1960,0,301,5,2020,0,313,5,2080,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4013] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2140,0,319,2,2200,0,313,2,2260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4014] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,2320,0,319,3,2380,0,313,3,2440,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4015] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2500,0,319,4,2560,0,313,4,2620,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4016] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,2680,0,319,5,2740,0,313,5,2800,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4017] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,2860,0,316,2,2920,0,313,2,2980,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4018] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,3,3040,0,316,3,3100,0,313,3,3160,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4019] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,3220,0,316,4,3280,0,313,4,3340,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4020] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,3400,0,316,5,3460,0,313,5,3520,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4021] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,3580,0,313,2,3640,0,316,2,3700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4022] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,3,3760,0,313,3,3820,0,316,3,3880,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4023] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,3940,0,313,4,4000,0,316,4,4060,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4024] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,5,4120,0,313,5,4180,0,316,5,4240,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4025] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,15000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4101] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,100,0,301,2,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4102] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,200,0,301,4,300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4103] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,400,0,301,5,500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4104] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,600,0,301,6,700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4105] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,800,0,316,2,900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4106] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,1000,0,316,4,1100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4107] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,1200,0,316,5,1300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4108] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,1380,0,309,1,2460,0,316,6,1540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4109] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,1620,0,319,2,1700,0,313,2,1780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4110] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,1840,0,319,3,1920,0,313,3,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4111] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2080,0,319,4,2160,0,313,4,2240,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4112] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,2320,0,313,4,2400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4113] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,2480,0,313,2,2560,0,316,2,2640,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4114] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,2720,0,313,3,2800,0,316,3,2880,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4115] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,2960,0,313,4,3040,0,316,4,3120,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4116] =
	{   
		pass_id = 3, 
		type_count_start1 = {321,1,3200,0,313,4,3280,0,316,4,3360,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4117] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,3440,0,316,2,3520,0,313,2,3600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4118] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,3680,0,316,3,3760,0,313,3,3840,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4119] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,3920,0,316,4,4000,0,313,4,4080,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4120] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,6,4150,0,313,4,4300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4121] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,3,4380,0,301,3,4460,0,304,3,4540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4122] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,4620,0,301,4,4700,0,304,4,4780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4123] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,4860,0,301,5,4940,0,304,5,5020,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4124] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,5100,0,301,6,5180,0,304,6,5260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4125] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,5340,0,309,1,6000,0,301,5,5420,0,303,1,6000,0,304,5,5500,0,306,1,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4201] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,100,0,304,2,150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4202] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,250,0,304,4,350,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4203] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,5,450,0,304,5,550,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4204] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,650,0,304,6,750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4205] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,850,0,316,2,750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4206] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,1050,0,316,4,950,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4207] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,5,1250,0,316,5,1150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4208] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,1450,0,303,1,1530,0,316,6,1410,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4209] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,1690,0,319,2,1770,0,316,2,1650,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4210] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,1930,0,319,3,2010,0,316,3,1890,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4211] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,2170,0,319,4,2250,0,316,4,2130,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4212] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,2410,0,316,6,2290,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4213] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,6,2570,0,316,2,2450,0,313,2,2530,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4214] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,4,2810,0,316,3,2690,0,313,3,2770,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4215] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,2,3050,0,316,4,2930,0,313,4,3010,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4216] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,4,3090,0,313,6,3170,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4217] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,3450,0,316,2,3330,0,313,2,3410,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4218] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,3690,0,316,3,3570,0,313,3,3650,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4219] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,3930,0,316,4,3850,0,313,4,3930,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4220] =
	{   
		pass_id = 3, 
		type_count_start1 = {306,1,5000,0,316,4,4090,0,313,4,4170,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4221] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,3,4450,0,307,3,4530,0,301,3,4610,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4222] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,4590,0,307,4,5670,0,301,4,4750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4223] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,4830,0,307,5,4910,0,301,5,4990,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4224] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,5070,0,307,6,5150,0,301,6,5230,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4225] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,5,5310,0,306,1,6000,0,307,5,5390,0,309,1,6000,0,301,5,5470,0,303,1,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4301] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,20,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4302] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,14,180,0,307,6,260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4303] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,10,340,0,307,10,420,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4304] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,500,0,307,14,580,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4305] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,14,640,0,319,6,720,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4306] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,10,800,0,319,10,880,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4307] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,960,0,319,14,1040,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4308] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,20,1160,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4309] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,14,1240,0,316,6,1320,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4310] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,10,1400,0,316,10,1480,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4311] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,1560,0,316,14,1640,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4312] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,20,1750,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4313] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,1800,0,304,8,1850,0,313,4,1900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4314] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,1950,0,304,6,2000,0,313,8,2050,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4315] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,2100,0,304,4,2150,0,313,12,2200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4316] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,2250,0,304,4,2300,0,313,8,2350,0,316,8,2400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4317] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,2450,0,301,8,2500,0,319,4,2550,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4318] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,2600,0,301,6,2650,0,319,8,2700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4319] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,2750,0,301,4,2800,0,319,12,2850,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4320] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,2900,0,301,2,2950,0,319,16,3000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4321] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,3050,0,319,4,3100,0,316,8,3150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4322] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,3200,0,319,8,3250,0,316,6,3300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4323] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,3350,0,319,12,3400,0,316,4,3450,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4324] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,3500,0,319,16,3550,0,316,2,3600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4325] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,16000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4401] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,20,80,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4402] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,14,140,0,301,6,220,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4403] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,10,300,0,301,10,380,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4404] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,460,0,301,14,540,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4405] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,14,620,0,319,6,700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4406] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,10,780,0,319,10,860,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4407] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,940,0,319,14,1020,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4408] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,20,1130,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4409] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,14,1210,0,313,6,990,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4410] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,10,1370,0,313,10,1150,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4411] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,1530,0,313,14,1310,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4412] =
	{   
		pass_id = 3, 
		type_count_start1 = {313,20,1400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4413] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,1780,0,307,8,1860,0,316,4,1640,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4414] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,2020,0,307,6,2100,0,316,8,1880,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4415] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2260,0,307,4,2340,0,316,12,1920,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4416] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,2300,0,307,4,2380,0,316,8,2160,0,313,8,2240,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4417] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,2620,0,304,8,2700,0,319,4,2780,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4418] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,2860,0,304,6,2940,0,319,8,3020,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4419] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,3100,0,304,4,3180,0,319,12,3260,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4420] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,3340,0,304,2,3420,0,319,16,3500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4421] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,3580,0,319,4,3640,0,313,8,3420,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4422] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,3800,0,319,8,3880,0,313,6,3660,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4423] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,4040,0,319,12,4120,0,313,4,3900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4424] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,2,4280,0,319,16,4360,0,313,2,4140,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4425] =
	{   
		pass_id = 3, 
		type_count_start1 = {311,1,18000,100}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4501] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,20,100,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4502] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,14,200,0,304,6,300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4503] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,10,400,0,304,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4504] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,600,0,304,14,700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4505] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,14,800,0,319,6,900,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4506] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,10,1050,0,319,10,1200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4507] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,1350,0,319,14,1500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4508] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,20,1700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4509] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,14,1850,0,316,6,1700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4510] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,10,2150,0,316,10,2000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4511] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,2550,0,316,14,2400,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4512] =
	{   
		pass_id = 3, 
		type_count_start1 = {316,10,2850,0,313,1,2700,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4513] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,8,3100,0,301,8,3200,0,313,4,3000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4514] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,6,3400,0,301,6,3500,0,313,8,3300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4515] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,3700,0,301,4,3800,0,313,12,3600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4516] =
	{   
		pass_id = 3, 
		type_count_start1 = {304,4,4000,0,301,4,4100,0,313,8,3900,0,316,8,4000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4517] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,8,4400,0,304,8,4500,0,319,4,4600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4518] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,6,4700,0,304,6,4800,0,319,8,4600,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4519] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,4,5000,0,304,4,5100,0,319,12,5200,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4520] =
	{   
		pass_id = 3, 
		type_count_start1 = {301,2,5300,0,304,2,5400,0,319,16,5500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4521] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,8,5600,0,319,4,5700,0,316,8,5500,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4522] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,6,5900,0,319,8,6000,0,316,6,5800,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4523] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,4,6200,0,319,12,6300,0,316,4,6000,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4524] =
	{   
		pass_id = 3, 
		type_count_start1 = {307,2,6400,0,319,16,6500,0,316,2,6300,0}, 
		type_count_start2 = {}
	}
LevelMonster3Config[4525] =
	{   
		pass_id = 3, 
		type_count_start1 = {319,20,6700,0,330,1,30000,0}, 
		type_count_start2 = {}
	}


function LevelMonster3Config.pass_id(id)
	return LevelMonster3Config[id].pass_id
end

function LevelMonster3Config.type_count_start1(id)
	return LevelMonster3Config[id].type_count_start1
end

function LevelMonster3Config.type_count_start2(id)
	return LevelMonster3Config[id].type_count_start2
end

        