-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-02 09:06:51
LevelMonster1Config = {}
LevelMonster1Config[101] =
	{   
		pass_id = 1, 
		type_count_start1 = {101,10,1,0},
		type_count_start2 = {}
	}
LevelMonster1Config[102] =
	{   
		pass_id = 1, 
		type_count_start1 = {101,8,57,0,119,2,88,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[103] =
	{   
		pass_id = 1, 
		type_count_start1 = {101,6,79,0,116,4,61,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[104] =
	{   
		pass_id = 1, 
		type_count_start1 = {119,5,169,0,104,5,118,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[105] =
	{   
		pass_id = 1, 
		type_count_start1 = {107,4,241,0,110,6,126,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[106] =
	{   
		pass_id = 1, 
		type_count_start1 = {104,8,190,0,116,2,136,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[107] =
	{   
		pass_id = 1, 
		type_count_start1 = {104,8,219,0,113,2,297,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[108] =
	{   
		pass_id = 1, 
		type_count_start1 = {101,8,229,0,110,2,194,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[109] =
	{   
		pass_id = 1, 
		type_count_start1 = {116,3,196,0,110,7,216,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[110] =
	{   
		pass_id = 1, 
		type_count_start1 = {102,1,1397,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[111] =
	{   
		pass_id = 1, 
		type_count_start1 = {113,3,485,2000,101,7,332,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[112] =
	{   
		pass_id = 1, 
		type_count_start1 = {104,4,423,0,116,6,302,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[113] =
	{   
		pass_id = 1, 
		type_count_start1 = {107,3,745,0,110,7,390,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[114] =
	{   
		pass_id = 1, 
		type_count_start1 = {119,7,829,0,101,3,539,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[115] =
	{   
		pass_id = 1, 
		type_count_start1 = {124,1,7522,3000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[201] =
	{   
		pass_id = 2, 
		type_count_start1 = {104,10,1,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[202] =
	{   
		pass_id = 2, 
		type_count_start1 = {101,6,61,0,107,4,99,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[203] =
	{   
		pass_id = 2, 
		type_count_start1 = {119,7,130,0,107,3,136,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[204] =
	{   
		pass_id = 2, 
		type_count_start1 = {119,6,178,0,101,4,116,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[205] =
	{   
		pass_id = 2, 
		type_count_start1 = {116,6,122,0,110,4,134,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[206] =
	{   
		pass_id = 2, 
		type_count_start1 = {107,7,303,0,104,3,202,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[207] =
	{   
		pass_id = 2, 
		type_count_start1 = {119,7,333,0,113,3,316,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[208] =
	{   
		pass_id = 2, 
		type_count_start1 = {101,8,244,0,116,2,188,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[209] =
	{   
		pass_id = 2, 
		type_count_start1 = {104,6,291,0,110,4,229,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[210] =
	{   
		pass_id = 2, 
		type_count_start1 = {117,1,1144,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[211] =
	{   
		pass_id = 2, 
		type_count_start1 = {119,3,544,0,116,4,272,0,101,3,354,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[212] =
	{   
		pass_id = 2, 
		type_count_start1 = {119,6,643,0,113,2,611,2000,104,2,450,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[213] =
	{   
		pass_id = 2, 
		type_count_start1 = {104,4,529,0,107,4,794,0,116,2,378,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[214] =
	{   
		pass_id = 2, 
		type_count_start1 = {101,4,573,0,107,3,926,0,110,3,485,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[215] =
	{   
		pass_id = 2, 
		type_count_start1 = {112,1,6775,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[301] =
	{   
		pass_id = 3, 
		type_count_start1 = {107,10,1,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[302] =
	{   
		pass_id = 3, 
		type_count_start1 = {104,4,75,0,119,6,107,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[303] =
	{   
		pass_id = 3, 
		type_count_start1 = {104,7,104,0,110,3,82,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[304] =
	{   
		pass_id = 3, 
		type_count_start1 = {119,4,206,0,107,6,216,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[305] =
	{   
		pass_id = 3, 
		type_count_start1 = {101,8,183,0,107,2,296,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[306] =
	{   
		pass_id = 3, 
		type_count_start1 = {104,6,232,0,116,4,166,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[307] =
	{   
		pass_id = 3, 
		type_count_start1 = {113,3,364,2000,119,7,383,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[308] =
	{   
		pass_id = 3, 
		type_count_start1 = {119,7,433,0,110,3,238,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[309] =
	{   
		pass_id = 3, 
		type_count_start1 = {107,7,504,0,116,3,240,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[310] =
	{   
		pass_id = 3, 
		type_count_start1 = {105,1,1844,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[311] =
	{   
		pass_id = 3, 
		type_count_start1 = {101,2,407,0,113,3,595,2000,107,5,657,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[312] =
	{   
		pass_id = 3, 
		type_count_start1 = {107,4,777,0,101,3,481,0,116,3,370,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[313] =
	{   
		pass_id = 3, 
		type_count_start1 = {119,4,869,0,110,2,478,0,101,4,565,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[314] =
	{   
		pass_id = 3, 
		type_count_start1 = {101,5,660,0,104,3,711,0,116,2,508,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[315] =
	{   
		pass_id = 3, 
		type_count_start1 = {127,1,5910,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[401] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,10,76,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[402] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,8,107,0,110,2,59,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[403] =
	{   
		pass_id = 4, 
		type_count_start1 = {101,5,97,0,104,5,104,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[404] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,4,216,0,104,6,144,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[405] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,7,282,0,101,3,183,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[406] =
	{   
		pass_id = 4, 
		type_count_start1 = {113,2,316,2000,110,8,183,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[407] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,4,401,0,116,6,191,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[408] =
	{   
		pass_id = 4, 
		type_count_start1 = {104,7,303,0,110,3,238,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[409] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,5,504,0,101,5,312,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[410] =
	{   
		pass_id = 4, 
		type_count_start1 = {102,1,1712,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[411] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,5,657,0,104,2,438,0,116,3,313,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[412] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,4,740,0,113,3,703,2000,104,3,518,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[413] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,2,913,0,101,6,565,0,110,2,478,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[414] =
	{   
		pass_id = 4, 
		type_count_start1 = {104,4,711,0,110,3,559,0,116,3,508,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[415] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,3,1182,0,104,4,827,0,116,3,591,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[416] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,4,1361,0,113,3,1232,2000,110,3,713,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[417] =
	{   
		pass_id = 4, 
		type_count_start1 = {104,2,986,0,119,5,1409,0,110,3,775,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[418] =
	{   
		pass_id = 4, 
		type_count_start1 = {119,2,1520,0,113,3,1444,2000,110,5,836,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[419] =
	{   
		pass_id = 4, 
		type_count_start1 = {107,4,1709,0,101,4,1058,0,116,2,814,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[420] =
	{   
		pass_id = 4, 
		type_count_start1 = {121,1,20794,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[501] =
	{   
		pass_id = 5, 
		type_count_start1 = {104,10,63,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[502] =
	{   
		pass_id = 5, 
		type_count_start1 = {119,8,127,0,110,2,70,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[503] =
	{   
		pass_id = 5, 
		type_count_start1 = {104,5,123,0,116,5,88,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[504] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,7,256,0,113,3,232,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[505] =
	{   
		pass_id = 5, 
		type_count_start1 = {101,5,217,0,104,5,234,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[506] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,3,416,0,116,7,198,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[507] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,4,491,0,104,6,327,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[508] =
	{   
		pass_id = 5, 
		type_count_start1 = {101,4,356,0,116,6,274,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[509] =
	{   
		pass_id = 5, 
		type_count_start1 = {119,7,641,0,104,3,449,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[510] =
	{   
		pass_id = 5, 
		type_count_start1 = {114,1,3543,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[511] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,4,932,0,101,2,577,0,110,4,488,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[512] =
	{   
		pass_id = 5, 
		type_count_start1 = {119,2,1048,0,116,3,524,0,110,5,576,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[513] =
	{   
		pass_id = 5, 
		type_count_start1 = {119,3,1231,0,113,3,1169,2000,110,4,677,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[514] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,2,1510,0,110,5,791,0,104,3,1007,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[515] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,3,1757,0,119,2,1673,0,104,5,1171,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[516] =
	{   
		pass_id = 5, 
		type_count_start1 = {107,4,1911,0,101,3,1183,0,116,3,910,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[517] =
	{   
		pass_id = 5, 
		type_count_start1 = {119,5,1964,0,110,2,1080,0,104,3,1375,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[518] =
	{   
		pass_id = 5, 
		type_count_start1 = {101,5,1366,0,116,3,1051,0,110,2,1156,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[519] =
	{   
		pass_id = 5, 
		type_count_start1 = {101,3,1455,0,119,3,2238,0,104,4,1567,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[520] =
	{   
		pass_id = 5, 
		type_count_start1 = {109,1,29889,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[601] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,7,84,0,104,3,56,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[602] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,6,118,0,110,4,62,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[603] =
	{   
		pass_id = 6, 
		type_count_start1 = {104,4,110,0,101,6,102,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[604] =
	{   
		pass_id = 6, 
		type_count_start1 = {104,8,151,0,110,2,119,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[605] =
	{   
		pass_id = 6, 
		type_count_start1 = {119,6,296,0,116,4,148,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[606] =
	{   
		pass_id = 6, 
		type_count_start1 = {104,7,246,0,116,3,176,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[607] =
	{   
		pass_id = 6, 
		type_count_start1 = {110,6,228,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[608] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,7,512,0,113,3,463,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[609] =
	{   
		pass_id = 6, 
		type_count_start1 = {104,4,399,0,119,6,570,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[610] =
	{   
		pass_id = 6, 
		type_count_start1 = {117,1,1657,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[611] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,4,829,0,104,3,552,0,110,3,434,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[612] =
	{   
		pass_id = 6, 
		type_count_start1 = {119,3,932,0,101,3,606,0,116,4,466,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[613] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,5,1149,0,113,3,1039,2000,116,2,547,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[614] =
	{   
		pass_id = 6, 
		type_count_start1 = {119,3,1278,0,116,3,639,0,110,4,703,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[615] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,3,1562,0,104,4,1041,0,110,3,818,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[616] =
	{   
		pass_id = 6, 
		type_count_start1 = {110,4,890,0,119,2,1618,0,104,4,1133,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[617] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,3,1833,0,119,4,1745,0,113,3,1658,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[618] =
	{   
		pass_id = 6, 
		type_count_start1 = {104,3,1308,0,101,5,1214,0,116,2,934,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[619] =
	{   
		pass_id = 6, 
		type_count_start1 = {107,3,2089,0,101,2,1293,0,110,5,1094,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[620] =
	{   
		pass_id = 6, 
		type_count_start1 = {106,1,17712,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[701] =
	{   
		pass_id = 7, 
		type_count_start1 = {101,12,52,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[702] =
	{   
		pass_id = 7, 
		type_count_start1 = {101,8,73,0,119,4,112,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[703] =
	{   
		pass_id = 7, 
		type_count_start1 = {101,6,103,0,116,6,79,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[704] =
	{   
		pass_id = 7, 
		type_count_start1 = {119,5,217,0,104,7,152,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[705] =
	{   
		pass_id = 7, 
		type_count_start1 = {107,6,311,0,110,6,163,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[706] =
	{   
		pass_id = 7, 
		type_count_start1 = {104,8,246,0,116,4,176,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[707] =
	{   
		pass_id = 7, 
		type_count_start1 = {104,9,291,0,113,3,395,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[708] =
	{   
		pass_id = 7, 
		type_count_start1 = {101,8,317,0,110,4,268,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[709] =
	{   
		pass_id = 7, 
		type_count_start1 = {116,6,285,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[710] =
	{   
		pass_id = 7, 
		type_count_start1 = {102,1,3016,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[711] =
	{   
		pass_id = 7, 
		type_count_start1 = {113,3,749,2000,101,7,512,0,116,2,394,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[712] =
	{   
		pass_id = 7, 
		type_count_start1 = {104,4,652,0,116,6,466,0,110,2,513,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[713] =
	{   
		pass_id = 7, 
		type_count_start1 = {107,4,1149,0,110,4,602,0,101,4,711,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[714] =
	{   
		pass_id = 7, 
		type_count_start1 = {119,7,1278,0,113,3,1215,2000,101,2,831,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[715] =
	{   
		pass_id = 7, 
		type_count_start1 = {106,1,15615,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[801] =
	{   
		pass_id = 8, 
		type_count_start1 = {119,12,120,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[802] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,8,177,0,104,4,118.490295892174,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[803] =
	{   
		pass_id = 8, 
		type_count_start1 = {113,3,223.615384615385,2000,101,9,153.437805868586,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[804] =
	{   
		pass_id = 8, 
		type_count_start1 = {101,8,211.9,0,116,4,162.844850796494,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[805] =
	{   
		pass_id = 8, 
		type_count_start1 = {104,3,311.818181818182,0,110,9,244.676606731825,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[806] =
	{   
		pass_id = 8, 
		type_count_start1 = {101,7,342.766267809688,0,107,5,554.076923076923,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[807] =
	{   
		pass_id = 8, 
		type_count_start1 = {110,8,342.50313263694,0,113,4,592.454545454545,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[808] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,4,768,0,104,8,512.026454854346,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[809] =
	{   
		pass_id = 8, 
		type_count_start1 = {119,9,855.384615384615,0,101,3,555.67464848064,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[810] =
	{   
		pass_id = 8, 
		type_count_start1 = {102,1,4525,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[811] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,4,1241.1,0,113,2,1122.9,2000,116,6,591.467780212143,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[812] =
	{   
		pass_id = 8, 
		type_count_start1 = {104,4,977.454545454545,0,107,4,1466.18181818182,0,110,4,768.31783807746,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[813] =
	{   
		pass_id = 8, 
		type_count_start1 = {119,8,1640,0,101,2,1066,0,110,2,902.471338382274,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[814] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,4,2013.9,0,116,4,958.8564620352,0,110,4,1054.9,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[815] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,4,2342.30769230769,0,104,4,1561.53846153846,0,101,4,1449.98005402149,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[816] =
	{   
		pass_id = 8, 
		type_count_start1 = {119,5,2427.69230769231,0,104,2,1699.38461538462,0,101,5,1577.86990592067,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[817] =
	{   
		pass_id = 8, 
		type_count_start1 = {104,7,1832.6,0,119,3,2618,0,116,2,1308.68130202813,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[818] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,4,2943.81818181818,0,104,3,1962.54545454545,0,110,5,1541.69954673914,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[819] =
	{   
		pass_id = 8, 
		type_count_start1 = {107,5,3133.2,0,116,5,1492.42577495395,0,113,2,2834.8,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[820] =
	{   
		pass_id = 8, 
		type_count_start1 = {121,1,41117,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[901] =
	{   
		pass_id = 9, 
		type_count_start1 = {110,12,66,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[902] =
	{   
		pass_id = 9, 
		type_count_start1 = {104,5,119,0,116,7,84.6359256372673,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[903] =
	{   
		pass_id = 9, 
		type_count_start1 = {119,6,236.363636363636,0,110,6,129.831989581111,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[904] =
	{   
		pass_id = 9, 
		type_count_start1 = {107,9,341.526315789474,0,113,3,309.405216513338,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[905] =
	{   
		pass_id = 9, 
		type_count_start1 = {101,8,289.163262501248,0,107,4,466.846153846154,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[906] =
	{   
		pass_id = 9, 
		type_count_start1 = {119,6,528,0,116,6,263.666359853606,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[907] =
	{   
		pass_id = 9, 
		type_count_start1 = {101,7,405.363636363636,0,110,5,342.50313263694,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[908] =
	{   
		pass_id = 9, 
		type_count_start1 = {107,7,768,0,104,5,512.026454854346,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[909] =
	{   
		pass_id = 9, 
		type_count_start1 = {101,4,555.454545454545,0,110,8,470.18624102208,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[910] =
	{   
		pass_id = 9, 
		type_count_start1 = {108,1,7309,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[911] =
	{   
		pass_id = 9, 
		type_count_start1 = {107,5,1241.1,0,104,3,827.4,0,116,4,591.467780212143,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[912] =
	{   
		pass_id = 9, 
		type_count_start1 = {119,5,1396,0,113,4,1326.2,2000,116,3,698.4707618886,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[913] =
	{   
		pass_id = 9, 
		type_count_start1 = {107,3,1722,0,119,5,1640,0,110,4,902.471338382275,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[914] =
	{   
		pass_id = 9, 
		type_count_start1 = {107,6,2014.09090909091,0,104,2,1342.72727272727,0,110,4,1054.74210823872,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[915] =
	{   
		pass_id = 9, 
		type_count_start1 = {121,1,29000,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1001] =
	{   
		pass_id = 10, 
		type_count_start1 = {116,12,10,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1002] =
	{   
		pass_id = 10, 
		type_count_start1 = {101,4,963.909153091099,0,104,8,964,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1003] =
	{   
		pass_id = 10, 
		type_count_start1 = {104,7,1213,0,116,5,1213.07667032857,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1004] =
	{   
		pass_id = 10, 
		type_count_start1 = {119,5,2002,0,110,7,2001.63462437357,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1005] =
	{   
		pass_id = 10, 
		type_count_start1 = {107,8,3213,0,116,4,3212.92513890276,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1006] =
	{   
		pass_id = 10, 
		type_count_start1 = {119,9,4691.42857142857,0,113,3,3283.95263511361,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1007] =
	{   
		pass_id = 10, 
		type_count_start1 = {110,6,2854.1927719745,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1008] =
	{   
		pass_id = 10, 
		type_count_start1 = {104,7,4712,0,110,5,2728.40844579491,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1009] =
	{   
		pass_id = 10, 
		type_count_start1 = {107,2,7479.81818181818,0,101,4,4630.36363636364,0,110,6,3918.218675184,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1010] =
	{   
		pass_id = 10, 
		type_count_start1 = {106,1,116016.321900391,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1101] =
	{   
		pass_id = 11, 
		type_count_start1 = {104,10,63,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1102] =
	{   
		pass_id = 11, 
		type_count_start1 = {119,8,127,0,110,2,70,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1103] =
	{   
		pass_id = 11, 
		type_count_start1 = {104,5,123,0,116,5,88,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1104] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,7,256,0,113,3,232,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1105] =
	{   
		pass_id = 11, 
		type_count_start1 = {101,5,217,0,104,5,234,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1106] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,3,416,0,116,7,198,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1107] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,4,491,0,104,6,327,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1108] =
	{   
		pass_id = 11, 
		type_count_start1 = {101,4,356,0,116,6,274,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1109] =
	{   
		pass_id = 11, 
		type_count_start1 = {119,7,641,0,104,3,449,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1110] =
	{   
		pass_id = 11, 
		type_count_start1 = {114,1,3543,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1111] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,4,932,0,101,2,577,0,110,4,488,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1112] =
	{   
		pass_id = 11, 
		type_count_start1 = {119,2,1048,0,116,3,524,0,110,5,576,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1113] =
	{   
		pass_id = 11, 
		type_count_start1 = {119,3,1231,0,113,3,1169,2000,110,4,677,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1114] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,2,1510,0,110,5,791,0,104,3,1007,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1115] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,3,1757,0,119,2,1673,0,104,5,1171,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1116] =
	{   
		pass_id = 11, 
		type_count_start1 = {107,4,1911,0,101,3,1183,0,116,3,910,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1117] =
	{   
		pass_id = 11, 
		type_count_start1 = {119,5,1964,0,110,2,1080,0,104,3,1375,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1118] =
	{   
		pass_id = 11, 
		type_count_start1 = {101,5,1366,0,116,3,1051,0,110,2,1156,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1119] =
	{   
		pass_id = 11, 
		type_count_start1 = {101,3,1455,0,119,3,2238,0,104,4,1567,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1120] =
	{   
		pass_id = 11, 
		type_count_start1 = {109,1,29889,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1201] =
	{   
		pass_id = 12, 
		type_count_start1 = {101,12,78,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1202] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,9,169.473684210526,0,113,3,160.808258710808,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1203] =
	{   
		pass_id = 12, 
		type_count_start1 = {107,4,248.181818181818,0,110,8,129.831989581111,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1204] =
	{   
		pass_id = 12, 
		type_count_start1 = {104,5,227.982791115091,0,119,7,325.714285714286,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1205] =
	{   
		pass_id = 12, 
		type_count_start1 = {101,2,289.545454545455,0,110,10,244.676606731825,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1206] =
	{   
		pass_id = 12, 
		type_count_start1 = {116,3,263.666359853606,0,107,9,554.4,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1207] =
	{   
		pass_id = 12, 
		type_count_start1 = {110,6,342.1,0,116,6,311.3664842154,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1208] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,7,731.466364077637,0,107,5,767.55,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1209] =
	{   
		pass_id = 12, 
		type_count_start1 = {107,8,898.153846153846,0,101,4,555.67464848064,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1210] =
	{   
		pass_id = 12, 
		type_count_start1 = {102,1,3231.88325293945,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1211] =
	{   
		pass_id = 12, 
		type_count_start1 = {116,4,591.467780212143,0,113,4,1122.9,2000,119,4,1182,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1212] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,2,1396.36363636364,0,101,4,907.636363636364,0,110,6,768.31783807746,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1213] =
	{   
		pass_id = 12, 
		type_count_start1 = {104,3,1148,0,116,5,820.428489438431,0,110,4,902,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1214] =
	{   
		pass_id = 12, 
		type_count_start1 = {107,3,2013,0,119,5,1917.14285714286,0,104,4,1342.39904684928,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1215] =
	{   
		pass_id = 12, 
		type_count_start1 = {113,2,2118.5,2000,116,6,1115.36927232422,0,101,4,1449.5,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1216] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,5,2427.27272727273,0,110,3,1335.12068962519,0,104,4,1699.09090909091,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1217] =
	{   
		pass_id = 12, 
		type_count_start1 = {107,3,2748.9,0,119,4,2618,0,116,5,1308.68130202813,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1218] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,2,2804,0,110,5,1542.2,0,116,5,1401.54504249013,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1219] =
	{   
		pass_id = 12, 
		type_count_start1 = {119,5,2984,0,113,3,2834.8,2000,116,4,1492.42577495395,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1220] =
	{   
		pass_id = 12, 
		type_count_start1 = {121,1,37964,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1301] =
	{   
		pass_id = 13, 
		type_count_start1 = {104,12,169.271851274535,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1302] =
	{   
		pass_id = 13, 
		type_count_start1 = {119,5,336.363636363636,0,113,3,319.545454545455,2000,110,4,185.474270830159,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1303] =
	{   
		pass_id = 13, 
		type_count_start1 = {104,6,326.2,0,113,2,442.7,2000,116,4,232.635501137848,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1304] =
	{   
		pass_id = 13, 
		type_count_start1 = {107,9,667.578947368421,0,113,3,603.747471156452,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1305] =
	{   
		pass_id = 13, 
		type_count_start1 = {101,5,489.666096870983,0,104,7,527.692307692308,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1306] =
	{   
		pass_id = 13, 
		type_count_start1 = {107,3,934.5,0,113,2,845.5,2000,116,7,444.809263164857,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1307] =
	{   
		pass_id = 13, 
		type_count_start1 = {104,9,731.466364077638,0,113,3,992.071428571429,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1308] =
	{   
		pass_id = 13, 
		type_count_start1 = {101,6,794.3,0,113,2,1160.9,2000,116,4,610.631481846857,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1309] =
	{   
		pass_id = 13, 
		type_count_start1 = {119,5,1420,0,113,3,1349,2000,104,4,994.425616289063,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1310] =
	{   
		pass_id = 13, 
		type_count_start1 = {114,1,8023,2000,110,7,929.449368904797,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1311] =
	{   
		pass_id = 13, 
		type_count_start1 = {107,4,2096.18181818182,0,101,4,1297.63636363636,0,110,4,1097.59691153923,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1312] =
	{   
		pass_id = 13, 
		type_count_start1 = {119,2,2344,0,113,5,2226.8,2000,116,5,1172.04069919776,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1313] =
	{   
		pass_id = 13, 
		type_count_start1 = {119,3,2740,0,113,3,2603,2000,110,6,1506.77444034103,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1314] =
	{   
		pass_id = 13, 
		type_count_start1 = {107,4,3345.3,0,113,3,3026.7,2000,116,5,1593.38467474888,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1315] =
	{   
		pass_id = 13, 
		type_count_start1 = {109,1,43685,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1401] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,12,160,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1402] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,8,241.818181818182,0,110,4,132.999311715706,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1403] =
	{   
		pass_id = 14, 
		type_count_start1 = {101,7,219.196865526552,0,104,5,235.846153846154,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1404] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,6,489,0,104,6,325.689701592987,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1405] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,7,635.384615384615,0,101,5,413.090375001783,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1406] =
	{   
		pass_id = 14, 
		type_count_start1 = {113,4,715.090909090909,2000,110,8,414.332851198524,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1407] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,6,934.5,0,116,6,444.809263164857,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1408] =
	{   
		pass_id = 14, 
		type_count_start1 = {104,7,731.818181818182,0,110,5,574.723571775287,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1409] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,7,1282.61538461538,0,101,5,793.820926400914,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1410] =
	{   
		pass_id = 14, 
		type_count_start1 = {102,1,4617,0,104,3,994,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1411] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,5,1774.5,0,104,4,1183,0,116,3,844.953971731634,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1412] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,4,1995.71428571429,0,113,3,1895.92857142857,2000,104,5,1396.9415237772,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1413] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,2,2460.81818181818,0,101,6,1523.36363636364,0,110,4,1289.24476911754,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1414] =
	{   
		pass_id = 14, 
		type_count_start1 = {104,4,1918,0,110,5,1507,0,116,3,1369.79494576457,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1415] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,5,3186,0,104,4,2230.2,0,116,3,1593.38467474888,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1416] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,6,3640.63636363636,0,113,3,3293.90909090909,2000,110,3,1907.31527089312,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1417] =
	{   
		pass_id = 14, 
		type_count_start1 = {104,2,2616.72727272727,0,119,7,3738.18181818182,0,110,3,2056.49918890135,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1418] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,4,4003.63636363636,0,113,3,3803.45454545455,2000,110,5,2202.42792391306,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1419] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,4,4477.2,0,101,4,2771.6,0,116,4,2132.03682136279,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1420] =
	{   
		pass_id = 14, 
		type_count_start1 = {121,1,54215,0,113,3,4292.38885945033,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1501] =
	{   
		pass_id = 14, 
		type_count_start1 = {101,12,162.5,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1502] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,7,378.181818181818,0,110,5,207.81142455579,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1503] =
	{   
		pass_id = 14, 
		type_count_start1 = {104,9,369.090909090909,0,110,3,289.803548172124,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1504] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,9,763.736842105263,0,113,3,690.636644002986,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1505] =
	{   
		pass_id = 14, 
		type_count_start1 = {104,7,695.8,0,116,6,496.502854569451,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1506] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,5,1177.14285714286,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1507] =
	{   
		pass_id = 14, 
		type_count_start1 = {116,7,695.014473695089,0,110,5,764.5,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1508] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,10,1632.73741981616,0,107,2,1714.65,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1509] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,8,1909.09090909091,0,110,4,1049.52285942429,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1510] =
	{   
		pass_id = 14, 
		type_count_start1 = {111,1,6104,0,104,5,1554,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1511] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,4,2772,0,119,4,2640,0,113,4,2508.45710357829,2000}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1512] =
	{   
		pass_id = 14, 
		type_count_start1 = {110,4,1714.99517428004,0,101,6,2026.81818181818,0,104,2,2182.72727272727,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1513] =
	{   
		pass_id = 14, 
		type_count_start1 = {101,5,2380.18181818182,0,113,3,3478.72727272727,2000,110,4,2014.44495174615,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1514] =
	{   
		pass_id = 14, 
		type_count_start1 = {110,6,2354.33506303286,0,119,4,4280,0,104,2,2996,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1515] =
	{   
		pass_id = 14, 
		type_count_start1 = {116,5,2489.66355429513,0,110,5,2739,0,104,2,3486,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1516] =
	{   
		pass_id = 14, 
		type_count_start1 = {113,4,5147.53846153846,2000,101,2,3522.0310400015,0,104,6,3792.92307692308,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1517] =
	{   
		pass_id = 14, 
		type_count_start1 = {119,4,5841.81818181818,0,110,5,3213.27998265836,0,104,3,4089.27272727273,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1518] =
	{   
		pass_id = 14, 
		type_count_start1 = {101,6,4066.98338222583,0,119,2,6256.92307692308,0,104,4,4379.84615384615,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1519] =
	{   
		pass_id = 14, 
		type_count_start1 = {107,6,6995.1,0,119,2,6662,0,116,4,3331.30753337936,0}, 
		type_count_start2 = {}
	}
LevelMonster1Config[1520] =
	{   
		pass_id = 14, 
		type_count_start1 = {130,1,59303,3000,107,5,7413,0}, 
		type_count_start2 = {}
	}


function LevelMonster1Config.pass_id(id)
	return LevelMonster1Config[id].pass_id
end

function LevelMonster1Config.type_count_start1(id)
	return LevelMonster1Config[id].type_count_start1
end

function LevelMonster1Config.type_count_start2(id)
	return LevelMonster1Config[id].type_count_start2
end

        