-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-10 17:58:07
LevelMonster2Config = {}
LevelMonster2Config[1601] =
	{   
		pass_id = 16, 
		type_count_start1 = {204,12,70,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1602] =
	{   
		pass_id = 16, 
		type_count_start1 = {213,5,153,0,201,7,95,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1603] =
	{   
		pass_id = 16, 
		type_count_start1 = {204,6,143,0,219,6,102,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1604] =
	{   
		pass_id = 16, 
		type_count_start1 = {201,8,182,0,204,4,196,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1605] =
	{   
		pass_id = 16, 
		type_count_start1 = {201,10,249,0,216,2,172,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1606] =
	{   
		pass_id = 16, 
		type_count_start1 = {207,7,250,0,213,5,477,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1607] =
	{   
		pass_id = 16, 
		type_count_start1 = {210,7,537,0,201,5,349,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1608] =
	{   
		pass_id = 16, 
		type_count_start1 = {216,4,284,1000,204,8,441,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1609] =
	{   
		pass_id = 16, 
		type_count_start1 = {201,6,479,0,210,6,737,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1610] =
	{   
		pass_id = 16, 
		type_count_start1 = {208,1,2357,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1611] =
	{   
		pass_id = 16, 
		type_count_start1 = {201,6,663,0,204,4,714,0,219,2,510,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1612] =
	{   
		pass_id = 16, 
		type_count_start1 = {216,3,542,1000,201,5,782,0,207,4,662,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1613] =
	{   
		pass_id = 16, 
		type_count_start1 = {204,5,990,0,210,3,1415,0,207,4,778,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1614] =
	{   
		pass_id = 16, 
		type_count_start1 = {201,4,1075,0,204,3,1158,0,219,5,827,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1615] =
	{   
		pass_id = 16, 
		type_count_start1 = {207,2,1058,0,204,5,1347,0,213,5,2020,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1616] =
	{   
		pass_id = 16, 
		type_count_start1 = {213,5,2197,0,207,5,1151,0,204,2,1465,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1617] =
	{   
		pass_id = 16, 
		type_count_start1 = {204,6,1579,0,210,3,2256,0,219,3,1128,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1618] =
	{   
		pass_id = 16, 
		type_count_start1 = {213,4,2537,0,201,3,1571,0,207,5,1329,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1619] =
	{   
		pass_id = 16, 
		type_count_start1 = {210,5,2573,0,216,3,1158,1000,207,4,1415,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1620] =
	{   
		pass_id = 16, 
		type_count_start1 = {209,1,17995,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1701] =
	{   
		pass_id = 17, 
		type_count_start1 = {210,12,100,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1702] =
	{   
		pass_id = 17, 
		type_count_start1 = {201,12,132,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1703] =
	{   
		pass_id = 17, 
		type_count_start1 = {207,10,154,0,219,2,140,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1704] =
	{   
		pass_id = 17, 
		type_count_start1 = {219,3,192,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1705] =
	{   
		pass_id = 17, 
		type_count_start1 = {213,8,478,0,216,4,205,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1706] =
	{   
		pass_id = 17, 
		type_count_start1 = {210,6,537,0,204,6,376,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1707] =
	{   
		pass_id = 17, 
		type_count_start1 = {201,7,410,0,207,5,347,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1708] =
	{   
		pass_id = 17, 
		type_count_start1 = {204,10,515,0,219,2,368,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1709] =
	{   
		pass_id = 17, 
		type_count_start1 = {207,5,472,0,219,7,429,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1710] =
	{   
		pass_id = 17, 
		type_count_start1 = {217,1,2294,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1711] =
	{   
		pass_id = 17, 
		type_count_start1 = {207,3,662,0,219,5,602,0,210,4,1204,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1712] =
	{   
		pass_id = 17, 
		type_count_start1 = {216,3,636,1000,201,7,919,0,204,2,990,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1713] =
	{   
		pass_id = 17, 
		type_count_start1 = {207,12,909,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1714] =
	{   
		pass_id = 17, 
		type_count_start1 = {219,5,962,0,216,3,866,1000,204,4,1347,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1715] =
	{   
		pass_id = 17, 
		type_count_start1 = {207,6,1151,0,210,3,2092,0,219,3,1046,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1716] =
	{   
		pass_id = 17, 
		type_count_start1 = {213,5,2369,0,201,3,1467,0,207,4,1241,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1717] =
	{   
		pass_id = 17, 
		type_count_start1 = {213,7,2537,0,210,3,2416,0,207,2,1329,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1718] =
	{   
		pass_id = 17, 
		type_count_start1 = {201,5,1672,0,210,4,2573,0,207,3,1415,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1719] =
	{   
		pass_id = 17, 
		type_count_start1 = {204,6,1908,0,216,4,1227,1000,201,2,1772,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1720] =
	{   
		pass_id = 17, 
		type_count_start1 = {221,1,17542,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1801] =
	{   
		pass_id = 18, 
		type_count_start1 = {201,12,65,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1802] =
	{   
		pass_id = 18, 
		type_count_start1 = {210,7,146,0,201,5,95,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1803] =
	{   
		pass_id = 18, 
		type_count_start1 = {204,6,143,0,219,6,102,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1804] =
	{   
		pass_id = 18, 
		type_count_start1 = {216,3,127,1000,201,9,183,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1805] =
	{   
		pass_id = 18, 
		type_count_start1 = {213,4,403,0,207,8,211,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1806] =
	{   
		pass_id = 18, 
		type_count_start1 = {201,8,295,0,207,4,250,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1807] =
	{   
		pass_id = 18, 
		type_count_start1 = {204,7,375,0,219,5,268,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1808] =
	{   
		pass_id = 18, 
		type_count_start1 = {210,6,630,0,219,6,315,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1809] =
	{   
		pass_id = 18, 
		type_count_start1 = {204,5,516,0,213,7,774,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1810] =
	{   
		pass_id = 18, 
		type_count_start1 = {208,1,2357,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1811] =
	{   
		pass_id = 18, 
		type_count_start1 = {201,5,663,0,204,3,714,0,207,4,561,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1812] =
	{   
		pass_id = 18, 
		type_count_start1 = {210,4,1204,0,201,6,783,0,219,2,602,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1813] =
	{   
		pass_id = 18, 
		type_count_start1 = {213,6,1485,0,216,3,637,1000,207,3,778,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1814] =
	{   
		pass_id = 18, 
		type_count_start1 = {204,5,1158,0,213,3,1737,0,201,4,1075,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1815] =
	{   
		pass_id = 18, 
		type_count_start1 = {210,6,1924,0,204,4,1347,0,219,2,962,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1816] =
	{   
		pass_id = 18, 
		type_count_start1 = {213,3,2197,0,204,2,1465,0,207,7,1151,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1817] =
	{   
		pass_id = 18, 
		type_count_start1 = {210,5,2256,0,216,3,1015,1000,207,4,1241,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1818] =
	{   
		pass_id = 18, 
		type_count_start1 = {201,7,1571,0,207,3,1329,0,204,2,1691,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1819] =
	{   
		pass_id = 18, 
		type_count_start1 = {207,5,1415,0,213,3,2701,0,201,4,1672,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1820] =
	{   
		pass_id = 18, 
		type_count_start1 = {224,1,27266,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1901] =
	{   
		pass_id = 19, 
		type_count_start1 = {210,12,120,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1902] =
	{   
		pass_id = 19, 
		type_count_start1 = {207,8,96,0,204,4,122,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1903] =
	{   
		pass_id = 19, 
		type_count_start1 = {204,8,171,0,201,4,159,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1904] =
	{   
		pass_id = 19, 
		type_count_start1 = {204,10,236,0,216,2,152,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1905] =
	{   
		pass_id = 19, 
		type_count_start1 = {210,6,460,0,219,6,230,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1906] =
	{   
		pass_id = 19, 
		type_count_start1 = {201,5,355,0,207,7,300,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1907] =
	{   
		pass_id = 19, 
		type_count_start1 = {213,7,677,0,216,5,290,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1908] =
	{   
		pass_id = 19, 
		type_count_start1 = {219,8,378,0,207,4,416,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1909] =
	{   
		pass_id = 19, 
		type_count_start1 = {204,10,619,0,207,2,486,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1910] =
	{   
		pass_id = 19, 
		type_count_start1 = {217,1,2315,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1911] =
	{   
		pass_id = 19, 
		type_count_start1 = {213,4,1284,0,201,5,795,0,204,3,856,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1912] =
	{   
		pass_id = 19, 
		type_count_start1 = {204,4,1012,0,201,4,940,0,207,4,795,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1913] =
	{   
		pass_id = 19, 
		type_count_start1 = {210,3,1698,0,201,4,1104,0,207,5,934,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1914] =
	{   
		pass_id = 19, 
		type_count_start1 = {213,6,2083,0,207,3,1091,0,219,3,992,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1915] =
	{   
		pass_id = 19, 
		type_count_start1 = {210,5,2308,0,201,3,1500,0,204,4,1615,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1916] =
	{   
		pass_id = 19, 
		type_count_start1 = {213,7,2638,0,201,2,1633,0,219,3,1256,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1917] =
	{   
		pass_id = 19, 
		type_count_start1 = {210,4,2707,0,216,5,1218,1000,204,3,1895,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1918] =
	{   
		pass_id = 19, 
		type_count_start1 = {213,2,3045,0,216,4,1305,1000,207,6,1595,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1919] =
	{   
		pass_id = 19, 
		type_count_start1 = {204,3,2161,0,210,5,3088,0,201,4,2007,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[1920] =
	{   
		pass_id = 19, 
		type_count_start1 = {203,1,25521,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2001] =
	{   
		pass_id = 20, 
		type_count_start1 = {207,12,77,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2002] =
	{   
		pass_id = 20, 
		type_count_start1 = {201,12,133,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2003] =
	{   
		pass_id = 20, 
		type_count_start1 = {210,12,285,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2004] =
	{   
		pass_id = 20, 
		type_count_start1 = {216,4,177,1000,207,8,216,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2005] =
	{   
		pass_id = 20, 
		type_count_start1 = {213,10,564,0,204,2,376,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2006] =
	{   
		pass_id = 20, 
		type_count_start1 = {201,8,413,0,219,4,318,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2007] =
	{   
		pass_id = 20, 
		type_count_start1 = {207,7,414,0,219,5,376,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2008] =
	{   
		pass_id = 20, 
		type_count_start1 = {210,10,883,0,201,2,574,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2009] =
	{   
		pass_id = 20, 
		type_count_start1 = {204,5,722,0,216,7,464,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2010] =
	{   
		pass_id = 20, 
		type_count_start1 = {208,1,660,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2011] =
	{   
		pass_id = 20, 
		type_count_start1 = {213,5,1499,0,207,4,785,0,210,3,1427,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2012] =
	{   
		pass_id = 20, 
		type_count_start1 = {219,4,843,0,216,5,759,1000,204,3,1180,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2013] =
	{   
		pass_id = 20, 
		type_count_start1 = {210,5,1980,0,213,2,2079,0,201,5,1287,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2014] =
	{   
		pass_id = 20, 
		type_count_start1 = {207,7,1273,0,210,3,2315,0,201,2,1504,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2015] =
	{   
		pass_id = 20, 
		type_count_start1 = {227,1,25846,2000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2101] =
	{   
		pass_id = 21, 
		type_count_start1 = {210,12,122,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2102] =
	{   
		pass_id = 21, 
		type_count_start1 = {213,5,187.090909090909,0,207,7,97.9150105217351,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2103] =
	{   
		pass_id = 21, 
		type_count_start1 = {213,6,261,0,204,6,173.78764749572,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2104] =
	{   
		pass_id = 21, 
		type_count_start1 = {201,7,222.648218416585,0,216,5,154.384615384615,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2105] =
	{   
		pass_id = 21, 
		type_count_start1 = {204,9,327.6,0,219,3,233.938448442654,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2106] =
	{   
		pass_id = 21, 
		type_count_start1 = {207,6,305.034702520293,0,210,6,554.545454545455,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2107] =
	{   
		pass_id = 21, 
		type_count_start1 = {210,10,654.545454545455,0,207,2,360.218811911265,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2108] =
	{   
		pass_id = 21, 
		type_count_start1 = {201,4,500.5,0,219,8,384.650415592551,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2109] =
	{   
		pass_id = 21, 
		type_count_start1 = {213,8,945,0,216,4,404.59599736853,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2110] =
	{   
		pass_id = 21, 
		type_count_start1 = {202,1,3399.04962809149,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2111] =
	{   
		pass_id = 21, 
		type_count_start1 = {204,4,870.8,0,201,3,808.6,0,219,5,622.060941257599,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2112] =
	{   
		pass_id = 21, 
		type_count_start1 = {219,5,734.598559917321,0,216,3,661.5,1000,207,4,808.5,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2113] =
	{   
		pass_id = 21, 
		type_count_start1 = {210,6,1725.45454545455,0,201,3,1121.54545454545,0,207,3,949.150890367565,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2114] =
	{   
		pass_id = 21, 
		type_count_start1 = {219,3,1008.45248593357,0,207,4,1108.8,0,204,5,1411.2,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2115] =
	{   
		pass_id = 21, 
		type_count_start1 = {213,7,2462.72727272727,0,207,3,1290.36686505095,0,210,2,2345.45454545455,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2116] =
	{   
		pass_id = 21, 
		type_count_start1 = {210,5,2552.85714285714,0,204,3,1787.13647169265,0,216,4,1148.78571428571,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2117] =
	{   
		pass_id = 21, 
		type_count_start1 = {201,6,1789.2832284626,0,204,3,1926.61538461538,0,216,3,1238.53846153846,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2118] =
	{   
		pass_id = 21, 
		type_count_start1 = {204,12,2063.65425221823,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2119] =
	{   
		pass_id = 21, 
		type_count_start1 = {201,5,2041,0,216,4,1413,1000,207,3,1726.58223274845,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2120] =
	{   
		pass_id = 21, 
		type_count_start1 = {212,1,33264.0661158855,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2201] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,12,77,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2202] =
	{   
		pass_id = 22, 
		type_count_start1 = {210,8,160,0,207,4,88.2840258802529,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2203] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,6,156.545454545455,0,207,6,123.116541844157,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2204] =
	{   
		pass_id = 22, 
		type_count_start1 = {210,7,308.888888888889,0,216,5,138.979657145283,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2205] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,9,295.4,0,219,3,210.928109251574,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2206] =
	{   
		pass_id = 22, 
		type_count_start1 = {201,9,325.036978095394,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2207] =
	{   
		pass_id = 22, 
		type_count_start1 = {213,10,619.5,0,219,2,295.261321238741,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2208] =
	{   
		pass_id = 22, 
		type_count_start1 = {210,10,693.846153846154,0,201,2,450.860733030613,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2209] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,6,567.636363636364,0,207,6,445.866263038179,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2210] =
	{   
		pass_id = 22, 
		type_count_start1 = {217,1,2546.07248308493,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2211] =
	{   
		pass_id = 22, 
		type_count_start1 = {213,4,1178.1,0,201,3,729.3,0,219,5,560.874619166688,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2212] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,3,927.818181818182,0,216,3,596.454545454545,1000,207,6,728.577260245868,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2213] =
	{   
		pass_id = 22, 
		type_count_start1 = {213,6,1633.8,0,204,3,1089.2,0,219,3,777.992533088168,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2214] =
	{   
		pass_id = 22, 
		type_count_start1 = {201,6,1181.81818181818,0,210,4,1818.18181818182,0,207,2,1000.18648195051,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2215] =
	{   
		pass_id = 22, 
		type_count_start1 = {213,4,2221.8,0,201,5,1375.4,0,219,3,1057.67775823848,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2216] =
	{   
		pass_id = 22, 
		type_count_start1 = {210,7,2301.81818181818,0,216,3,1035.81818181818,1000,207,2,1266.06272292043,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2217] =
	{   
		pass_id = 22, 
		type_count_start1 = {204,3,1737.07692307692,0,210,5,2481.53846153846,0,201,4,1613.28815681054,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2218] =
	{   
		pass_id = 22, 
		type_count_start1 = {216,5,1196.18181818182,1000,201,4,1727.81818181818,0,207,3,1461.9564667354,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2219] =
	{   
		pass_id = 22, 
		type_count_start1 = {213,5,2972.45454545455,0,207,3,1556.75447215024,0,201,4,1840.09090909091,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2220] =
	{   
		pass_id = 22, 
		type_count_start1 = {203,1,23393.9087929752,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2301] =
	{   
		pass_id = 23, 
		type_count_start1 = {207,12,77,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2302] =
	{   
		pass_id = 23, 
		type_count_start1 = {207,9,112.361487483958,0,216,3,91.6363636363636,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2303] =
	{   
		pass_id = 23, 
		type_count_start1 = {201,8,185.183558806914,0,204,4,199.230769230769,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2304] =
	{   
		pass_id = 23, 
		type_count_start1 = {210,9,394,0,219,3,196.53688889232,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2305] =
	{   
		pass_id = 23, 
		type_count_start1 = {213,8,563.181818181818,0,207,4,295.299352952203,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2306] =
	{   
		pass_id = 23, 
		type_count_start1 = {210,7,635.555555555556,0,216,5,286.396218461676,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2307] =
	{   
		pass_id = 23, 
		type_count_start1 = {213,6,789.6,0,219,6,375.787136122035,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2308] =
	{   
		pass_id = 23, 
		type_count_start1 = {201,6,573.822751129871,0,210,6,883.076923076923,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2309] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,10,722.4,0,219,2,515.878320870621,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2310] =
	{   
		pass_id = 23, 
		type_count_start1 = {208,1,3300.46432992491,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2311] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,4,999.384615384615,0,201,3,927.992551712156,0,213,5,1499.07692307692,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2312] =
	{   
		pass_id = 23, 
		type_count_start1 = {219,7,842.981954003483,0,201,2,1095.9,0,216,3,758.7,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2313] =
	{   
		pass_id = 23, 
		type_count_start1 = {207,6,1089,0,216,3,891,1000,219,3,990.172314839486,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2314] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,5,1619.69230769231,0,201,3,1504.4127249173,0,210,4,2313.84615384615,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2315] =
	{   
		pass_id = 23, 
		type_count_start1 = {213,3,2827.36363636364,0,204,5,1884.90909090909,0,207,4,1480.74886153388,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2316] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,4,2050.36363636364,0,216,5,1318.09090909091,1000,207,3,1611.35255644419,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2317] =
	{   
		pass_id = 23, 
		type_count_start1 = {207,5,1737.38724579597,0,210,3,3158.18181818182,0,201,4,2052.81818181818,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2318] =
	{   
		pass_id = 23, 
		type_count_start1 = {219,3,1691.5198788674,0,201,3,2199.6,0,213,6,3553.2,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2319] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,5,2521.27272727273,0,216,3,1620.81818181818,1000,207,4,1981.32387364577,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2320] =
	{   
		pass_id = 23, 
		type_count_start1 = {211,1,19085.9395746884,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2321] =
	{   
		pass_id = 23, 
		type_count_start1 = {213,5,4298.7,0,219,3,2047.24662619146,0,207,4,2251.7,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2322] =
	{   
		pass_id = 23, 
		type_count_start1 = {204,6,3050.6,0,219,3,2178.84352150697,0,201,3,2832.7,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2323] =
	{   
		pass_id = 23, 
		type_count_start1 = {213,4,4840.5,0,216,4,2074.5,1000,204,4,3226.81127644443,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2324] =
	{   
		pass_id = 23, 
		type_count_start1 = {219,5,2425.76491451802,0,201,4,3153.8,0,213,3,5094.6,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2325] =
	{   
		pass_id = 23, 
		type_count_start1 = {215,1,64056.9588371158,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2401] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,12,84.5,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2402] =
	{   
		pass_id = 24, 
		type_count_start1 = {210,10,190,0,219,2,94.8506063176271,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2403] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,8,171.956161749278,0,204,4,185.230769230769,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2404] =
	{   
		pass_id = 24, 
		type_count_start1 = {207,10,200.748393654298,0,216,2,164.454545454545,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2405] =
	{   
		pass_id = 24, 
		type_count_start1 = {207,4,274.206542027046,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2406] =
	{   
		pass_id = 24, 
		type_count_start1 = {213,8,621,0,204,4,413.683426666865,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2407] =
	{   
		pass_id = 24, 
		type_count_start1 = {216,4,314.1,1000,219,8,348.945197827603,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2408] =
	{   
		pass_id = 24, 
		type_count_start1 = {207,6,450.860733030613,0,210,6,820,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2409] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,7,622.7,0,219,5,479.029869379862,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2410] =
	{   
		pass_id = 24, 
		type_count_start1 = {202,1,3621.93812829422,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2411] =
	{   
		pass_id = 24, 
		type_count_start1 = {210,6,1326,0,219,3,662.85182265154,0,216,3,596.7,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2412] =
	{   
		pass_id = 24, 
		type_count_start1 = {204,5,1096.2,0,207,2,861.3,0,219,5,782.768957288949,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2413] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,4,1194.7,0,219,3,919.44572092238,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2414] =
	{   
		pass_id = 24, 
		type_count_start1 = {207,4,1182.03856957788,0,204,6,1504.36363636364,0,213,2,2256.54545454545,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2415] =
	{   
		pass_id = 24, 
		type_count_start1 = {213,5,2625,0,210,5,2500,0,216,2,1124.98452467184,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2416] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,4,1768,0,219,5,1360.23267751782,0,207,3,1496,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2417] =
	{   
		pass_id = 24, 
		type_count_start1 = {210,6,2932.85714285714,0,213,3,3079.5,0,204,3,2053.27583594069,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2418] =
	{   
		pass_id = 24, 
		type_count_start1 = {210,5,3141.81818181818,0,207,3,1727.76673341456,0,201,4,2042.18181818182,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2419] =
	{   
		pass_id = 24, 
		type_count_start1 = {201,6,2174.9,0,210,3,3346,0,219,3,1672.54612710357,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2420] =
	{   
		pass_id = 24, 
		type_count_start1 = {206,1,29774.0657365139,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2501] =
	{   
		pass_id = 25, 
		type_count_start1 = {210,12,124,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2502] =
	{   
		pass_id = 25, 
		type_count_start1 = {204,10,127.076923076923,0,201,2,117.614751833858,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2503] =
	{   
		pass_id = 25, 
		type_count_start1 = {219,9,126.169018088227,0,207,3,138.6,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2504] =
	{   
		pass_id = 25, 
		type_count_start1 = {201,7,225.727272727273,0,207,5,191.483083177946,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2505] =
	{   
		pass_id = 25, 
		type_count_start1 = {213,8,499.333333333333,0,216,4,213.996154477051,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2506] =
	{   
		pass_id = 25, 
		type_count_start1 = {210,6,564,0,219,6,281.850246740062,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2507] =
	{   
		pass_id = 25, 
		type_count_start1 = {204,8,465.976048791323,0,216,4,299.571428571429,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2508] =
	{   
		pass_id = 25, 
		type_count_start1 = {213,6,820.909090909091,0,207,6,430.051776121508,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2509] =
	{   
		pass_id = 25, 
		type_count_start1 = {204,5,639.689117879569,0,210,7,914.285714285714,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2510] =
	{   
		pass_id = 25, 
		type_count_start1 = {214,1,5580.78513969121,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2511] =
	{   
		pass_id = 25, 
		type_count_start1 = {204,3,884.545454545454,0,216,3,568.636363636364,1000,207,6,695.484527766693,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2512] =
	{   
		pass_id = 25, 
		type_count_start1 = {210,5,1493.84615384615,0,213,4,1568.53846153846,0,201,3,970.633507038296,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2513] =
	{   
		pass_id = 25, 
		type_count_start1 = {210,7,1754,0,204,2,1227.8,0,219,3,877.009764572116,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2514] =
	{   
		pass_id = 25, 
		type_count_start1 = {213,6,2151.54545454545,0,201,3,1331.90909090909,0,207,3,1127.48294328967,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2515] =
	{   
		pass_id = 25, 
		type_count_start1 = {212,1,28614.9909865248,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2601] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,12,147,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2602] =
	{   
		pass_id = 26, 
		type_count_start1 = {210,7,204.615384615385,0,201,5,132.790848844678,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2603] =
	{   
		pass_id = 26, 
		type_count_start1 = {210,9,285.454545454545,0,207,3,156.693780528928,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2604] =
	{   
		pass_id = 26, 
		type_count_start1 = {204,8,275.151644449248,0,216,4,176.785714285714,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2605] =
	{   
		pass_id = 26, 
		type_count_start1 = {219,7,268.453957229275,0,204,5,375.2,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2606] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,6,667.8,0,210,6,636.436041025946,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2607] =
	{   
		pass_id = 26, 
		type_count_start1 = {210,10,752,0,219,2,375.787136122035,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2608] =
	{   
		pass_id = 26, 
		type_count_start1 = {210,8,883.636363636364,0,207,5,485.542327879122,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2609] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,5,1083.6,0,219,7,515.878320870621,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2610] =
	{   
		pass_id = 26, 
		type_count_start1 = {208,1,3300.46432992491,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2611] =
	{   
		pass_id = 26, 
		type_count_start1 = {204,5,999.384615384615,0,216,5,642.461538461538,1000,201,2,927.992551712156,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2612] =
	{   
		pass_id = 26, 
		type_count_start1 = {210,5,1685.71428571429,0,213,4,1770,0,204,3,1180.17473560488,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2613] =
	{   
		pass_id = 26, 
		type_count_start1 = {204,3,1386,0,207,5,1089.18954632343,0,201,4,1287,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2614] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,6,2429.7,0,219,3,1157.24055762869,0,216,3,1041.3,1000}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2615] =
	{   
		pass_id = 26, 
		type_count_start1 = {219,5,1346.13532866716,0,210,4,2692,0,201,3,1749.8,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2616] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,6,3075.69230769231,0,210,3,2929.23076923077,0,201,3,1904.32574852495,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2617] =
	{   
		pass_id = 26, 
		type_count_start1 = {207,3,1737.38724579597,0,213,7,3316.09090909091,0,204,2,2210.72727272727,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2618] =
	{   
		pass_id = 26, 
		type_count_start1 = {219,3,1691.5198788674,0,207,5,1861.2,0,210,4,3384,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2619] =
	{   
		pass_id = 26, 
		type_count_start1 = {213,7,3783.23076923077,0,216,3,1621.38461538462,1000,201,2,2341.564577945,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2620] =
	{   
		pass_id = 26, 
		type_count_start1 = {206,1,32064.3784854765,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2701] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2702] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2703] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2704] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2705] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2706] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2707] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2708] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2709] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2710] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2711] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2712] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2713] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2714] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2715] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2716] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2717] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2718] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2719] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2720] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2721] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2722] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2723] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2724] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}
LevelMonster2Config[2725] =
	{   
		pass_id = 27, 
		type_count_start1 = {404,10,500,0}, 
		type_count_start2 = {}
	}


function LevelMonster2Config.pass_id(id)
	return LevelMonster2Config[id].pass_id
end

function LevelMonster2Config.type_count_start1(id)
	return LevelMonster2Config[id].type_count_start1
end

function LevelMonster2Config.type_count_start2(id)
	return LevelMonster2Config[id].type_count_start2
end

        